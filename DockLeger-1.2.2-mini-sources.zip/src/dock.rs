// Dock Léger 1.2.2 « mini » — dock de lancement Windows en Rust sans std ni runtime, réduit à l'essentiel.
// Un seul .exe : il s'installe ou fonctionne en portable. (c) christ13430 — licence MIT
#![no_std]
#![no_main]
#![allow(static_mut_refs, unsafe_op_in_unsafe_fn, non_upper_case_globals, clippy::all)]

#[macro_use]
mod common;
use common::*;
use core::ptr::{null, null_mut};

const APPNAME: &[u16] = w!("Dock Léger");
const CLASS: &[u16] = w!("DockLegerWnd");
const MAXITEMS: usize = 48;

#[derive(Clone, Copy)]
struct Item { raw: [u16; MAX_PATH], px: *mut u32, pw: i32 }
const EMPTY: Item = Item { raw: [0; MAX_PATH], px: null_mut(), pw: 0 };

static mut ITEMS: [Item; MAXITEMS] = [EMPTY; MAXITEMS];
static mut N: usize = 0;
static mut HOVER: i32 = -1;
static mut PRESSED: i32 = -1;
static mut DRAGGED: bool = false;
static mut TRACKING: bool = false;
static mut POSTOP: bool = false;
static mut ENGLISH: bool = false;
static mut B: i32 = 48; static mut SLOT: i32 = 0; static mut PAD: i32 = 0; static mut W: i32 = 0; static mut HH: i32 = 0;
static mut HWND: H = 0;
static mut INI: [u16; MAX_PATH] = [0; MAX_PATH];
static mut TMP: [u16; 600] = [0; 600];

// ---------- textes FR / EN (stockés en Latin-1) ----------
#[derive(Clone, Copy)]
enum S { Remove, Bottom, Top, Startup, Lang, Quit, Install, Done, UnQ, UnDone, Add, Filter }
static T: [[&[u8]; 12]; 2] = [
  [a!("Retirer"), a!("En bas"), a!("En haut"), a!("Lancer avec Windows"), a!("English"), a!("Quitter"),
   a!("Installer Dock Léger ?\nOui : installer   Non : portable, ici"), a!("Installé ! Glissez vos raccourcis sur le dock."),
   a!("Désinstaller Dock Léger ?"), a!("Désinstallé."), a!("Ajouter un programme..."),
   a!("Programmes\0*.exe;*.lnk;*.url;*.bat\0Tout\0*.*\0")],
  [a!("Remove"), a!("Bottom"), a!("Top"), a!("Start with Windows"), a!("Français"), a!("Quit"),
   a!("Install Dock Léger?\nYes: install   No: portable, here"), a!("Installed! Drop your shortcuts on the dock."),
   a!("Uninstall Dock Léger?"), a!("Uninstalled."), a!("Add a program..."),
   a!("Programs\0*.exe;*.lnk;*.url;*.bat\0All\0*.*\0")]];
#[inline(never)] unsafe fn s(i: S) -> *const u16 { wide(T[ENGLISH as usize][i as usize]) }
#[inline(never)] unsafe fn msg(i: S, f: u32) -> i32 { MessageBoxW(HWND, s(i), APPNAME.as_ptr(), f) }

// ---------- pixels ARGB prémultipliés ----------
#[inline(never)] fn pm(rgb: u32, a: u32) -> u32 {
  (a << 24) | ((((rgb >> 16) & 255) * a / 255) << 16) | ((((rgb >> 8) & 255) * a / 255) << 8) | ((rgb & 255) * a / 255)
}
#[inline(never)] unsafe fn blend(d: *mut u32, s: u32) {
  let (ia, o) = (255 - (s >> 24), *d);
  *d = s + ((((o & 0xFF00FF) * ia >> 8) & 0xFF00FF) | ((((o >> 8) & 0xFF00FF) * ia >> 8) & 0xFF00FF) << 8);
}
#[inline(never)] fn lerp(a: u32, b: u32, f: u32) -> u32 {
  ((((a & 0xFF00FF) * (256 - f) + (b & 0xFF00FF) * f) >> 8) & 0xFF00FF)
    | (((((a >> 8) & 0xFF00FF) * (256 - f) + ((b >> 8) & 0xFF00FF) * f) >> 8) & 0xFF00FF) << 8
}
/// rectangle arrondi anticrénelé (couverture estimée au seizième de pixel)
#[inline(never)] unsafe fn round_rect(fb: *mut u32, x: i32, y: i32, w: i32, h: i32, r: i32, rgb: u32, a: i32) {
  for py in y..y + h { for px in x..x + w {
    let dx = (x + r - px).max(px - (x + w - r - 1)).max(0);
    let dy = (y + r - py).max(py - (y + h - r - 1)).max(0);
    let mut d = 0; while d * d < (dx * dx + dy * dy) * 256 { d += 1; } // distance × 16
    let c = ((r * 16 - d + 8) * 16).max(0).min(256);
    blend(fb.add((py * W + px) as usize), pm(rgb, (a * c >> 8) as u32));
  } }
}

// ---------- icônes ----------
/// pixels prémultipliés (carrés) d'une HICON, qui est détruite
#[inline(never)] unsafe fn icon_bits(hi: H, pw: &mut i32) -> *mut u32 {
  let mut ii: ICONINFO = core::mem::zeroed();
  let mut bm: BITMAP = core::mem::zeroed();
  let mut out = null_mut();
  if GetIconInfo(hi, &mut ii) != 0 {
    if GetObjectW(ii.color, 32, &mut bm) != 0 && bm.w > 0 && bm.w <= 256 {
      let (w, n) = (bm.w, (bm.w * bm.w) as usize);
      let mut bi: BITMAPINFO = core::mem::zeroed();
      bi.h.size = 40; bi.h.w = w; bi.h.h = -w; bi.h.planes = 1; bi.h.bits = 32;
      let dc = GetDC(0);
      let buf = alloc(n * 8) as *mut u32; // pixels + masque
      GetDIBits(dc, ii.color, 0, w as u32, buf, &mut bi, 0);
      let mut alpha = 0;
      for i in 0..n { alpha |= *buf.add(i) >> 24; }
      if alpha == 0 { GetDIBits(dc, ii.mask, 0, w as u32, buf.add(n), &mut bi, 0); } // vieille icône sans alpha
      for i in 0..n {
        let c = *buf.add(i);
        *buf.add(i) = pm(c, if alpha != 0 { c >> 24 } else if *buf.add(n + i) & 0xFFFFFF != 0 { 0 } else { 255 });
      }
      *pw = w; out = buf;
      ReleaseDC(0, dc);
    }
    DeleteObject(ii.color); DeleteObject(ii.mask);
  }
  DestroyIcon(hi);
  out
}
/// icône à la bonne taille tirée du fichier ; sinon celle de l'Explorateur (32 px)
#[inline(never)] unsafe fn load_icon(i: usize) {
  let mut path = [0u16; MAX_PATH];
  ExpandEnvironmentStringsW(ITEMS[i].raw.as_ptr(), path.as_mut_ptr(), MAX_PATH as u32);
  let mut fi: SHFILEINFOW = core::mem::zeroed();
  let sz = core::mem::size_of::<SHFILEINFOW>() as u32;
  let mut hi = 0;
  if SHGetFileInfoW(path.as_ptr(), 0, &mut fi, sz, 0x1000 /*ICONLOCATION*/) != 0 {
    let mut id = 0;
    ExpandEnvironmentStringsW(fi.name.as_ptr(), path.as_mut_ptr(), MAX_PATH as u32);
    PrivateExtractIconsW(path.as_ptr(), fi.iicon, B, B, &mut hi, &mut id, 1, 0);
    ExpandEnvironmentStringsW(ITEMS[i].raw.as_ptr(), path.as_mut_ptr(), MAX_PATH as u32);
  }
  if hi == 0 {
    if SHGetFileInfoW(path.as_ptr(), 0, &mut fi, sz, 0x100 /*ICON*/) == 0 {
      SHGetFileInfoW(path.as_ptr(), 0x80, &mut fi, sz, 0x110 /*ICON|USEFILEATTRIBUTES*/);
    }
    hi = fi.icon;
  }
  ITEMS[i].px = icon_bits(hi, &mut ITEMS[i].pw);
}

// ---------- éléments et configuration (dock.ini en Unicode) ----------
/// décale les éléments à partir de `at` d'une case vers la droite ou la gauche
#[inline(never)] unsafe fn shift(at: usize, count: usize, right: bool) {
  let p = ITEMS.as_mut_ptr().add(at) as *mut u8; let sz = core::mem::size_of::<Item>();
  if right { memmove(p.add(sz), p, count * sz); } else { memmove(p, p.add(sz), count * sz); }
}
#[inline(never)] unsafe fn add_item(raw: *const u16, at: usize) {
  if N >= MAXITEMS { return; }
  let at = at.min(N);
  shift(at, N - at, true);
  ITEMS[at] = EMPTY;
  wcopy(&mut ITEMS[at].raw, ws(raw));
  load_icon(at); N += 1;
}
#[inline(never)] unsafe fn ini(k: *const u16, v: *const u16) { WritePrivateProfileStringW(w!("Dock").as_ptr(), k, v, INI.as_ptr()); }
#[inline(never)] unsafe fn num(v: usize) -> [u16; 8] { let mut b = [0u16; 8]; wcat_int(&mut b, v as i64); b }
#[inline(never)] unsafe fn save() {
  let f = CreateFileW(INI.as_ptr(), 0x40000000, 0, 0, 1 /*CREATE_NEW*/, 0x80, 0);
  if f != usize::MAX { let mut wr = 0; WriteFile(f, [0xFFu8, 0xFE].as_ptr(), 2, &mut wr, 0); CloseHandle(f); } // INI Unicode
  ini(null(), null());
  ini(w!("Top").as_ptr(), num(POSTOP as usize).as_ptr());
  ini(w!("English").as_ptr(), num(ENGLISH as usize).as_ptr());
  for i in 0..N { ini(num(i + 1).as_ptr(), ITEMS[i].raw.as_ptr()); }
}
#[inline(never)] unsafe fn get(k: &[u16]) -> bool { GetPrivateProfileIntW(w!("Dock").as_ptr(), k.as_ptr(), 0, INI.as_ptr()) != 0 }

// ---------- registre et installation ----------
const RUNKEY: &[u16] = w!("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
const UNKEY: &[u16] = w!("Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\DockLeger");
const NAME: &[u16] = w!("DockLeger");
#[inline(never)] unsafe fn reg(path: &[u16]) -> H { let mut k = 0; RegCreateKeyExW(HKCU, path.as_ptr(), 0, 0, 0, 0x2001F, 0, &mut k, 0); k }
#[inline(never)] unsafe fn reg_str(k: H, name: &[u16], v: &[u16]) {
  RegSetValueExW(k, name.as_ptr(), 0, 1 /*REG_SZ*/, v.as_ptr() as *const u8, (wlen(v) as u32 + 1) * 2);
}
#[inline(never)] unsafe fn quoted(v: &mut [u16], p: &[u16], tail: &[u16]) { wcopy(v, w!("\"")); wcat(v, p); wcat(v, w!("\"")); wcat(v, tail); }
#[inline(never)] unsafe fn is_startup() -> bool { RegQueryValueExW(reg(RUNKEY), NAME.as_ptr(), 0, 0, 0, 0) == 0 }
#[inline(never)] unsafe fn set_startup(on: bool) {
  let (mut e, mut v) = ([0u16; MAX_PATH], [0u16; MAX_PATH + 4]);
  exe_path(&mut e); quoted(&mut v, &e, w!(""));
  if on { reg_str(reg(RUNKEY), NAME, &v); } else { RegDeleteValueW(reg(RUNKEY), NAME.as_ptr()); }
}
#[inline(never)] unsafe fn folder(csidl: i32, sub: &[u16], out: &mut [u16; MAX_PATH]) { SHGetFolderPathW(0, csidl, 0, 0, out.as_mut_ptr()); wcat(out, sub); }
#[inline(never)] unsafe fn close_running() { PostMessageW(FindWindowW(CLASS.as_ptr(), null()), 0x10 /*WM_CLOSE*/, 0, 0); Sleep(800); }
const LNK: &[u16] = w!("\\Dock Léger.lnk");

static CLSID_SHELLLINK: GUID = GUID { d1: 0x00021401, d2: 0, d3: 0, d4: [0xC0, 0, 0, 0, 0, 0, 0, 0x46] };
static IID_ISHELLLINKW: GUID = GUID { d1: 0x000214F9, d2: 0, d3: 0, d4: [0xC0, 0, 0, 0, 0, 0, 0, 0x46] };
static IID_IPERSISTFILE: GUID = GUID { d1: 0x0000010B, d2: 0, d3: 0, d4: [0xC0, 0, 0, 0, 0, 0, 0, 0x46] };
#[inline(never)] unsafe fn com(o: usize, i: usize) -> usize { *(*(o as *const *const usize)).add(i) }

unsafe fn install(dir: &mut [u16; MAX_PATH]) {
  let (mut exe, mut me, mut lnk, mut v) = ([0u16; MAX_PATH], [0u16; MAX_PATH], [0u16; MAX_PATH], [0u16; MAX_PATH + 16]);
  close_running();
  let l = wlen(dir); dir[l - 10] = 0; CreateDirectoryW(dir.as_ptr(), 0); dir[l - 10] = 92; // …\Programs puis …\DockLeger
  CreateDirectoryW(dir.as_ptr(), 0);
  wcopy(&mut exe, dir); wcat(&mut exe, w!("\\DockLeger.exe"));
  exe_path(&mut me);
  if CopyFileW(me.as_ptr(), exe.as_ptr(), 0) == 0 { return; }
  // raccourci du menu Démarrer (IShellLinkW::SetPath puis IPersistFile::Save)
  let (mut sl, mut pf) = (0usize, 0usize);
  folder(2 /*CSIDL_PROGRAMS*/, LNK, &mut lnk);
  if CoCreateInstance(&CLSID_SHELLLINK, 0, 1, &IID_ISHELLLINKW, &mut sl) == 0 {
    let set: unsafe extern "win64" fn(usize, *const u16) -> i32 = core::mem::transmute(com(sl, 20)); set(sl, exe.as_ptr());
    let qi: unsafe extern "win64" fn(usize, *const GUID, *mut usize) -> i32 = core::mem::transmute(com(sl, 0));
    if qi(sl, &IID_IPERSISTFILE, &mut pf) == 0 {
      let sv: unsafe extern "win64" fn(usize, *const u16, i32) -> i32 = core::mem::transmute(com(pf, 6)); sv(pf, lnk.as_ptr(), 1);
    }
  }
  // entrée « Applications installées » de Windows
  let k = reg(UNKEY);
  quoted(&mut v, &exe, w!(" /uninstall"));
  reg_str(k, w!("UninstallString"), &v); reg_str(k, w!("DisplayName"), APPNAME); reg_str(k, w!("DisplayIcon"), &exe);
  ShellExecuteW(0, null(), exe.as_ptr(), null(), null(), 1);
  msg(S::Done, 0x40);
}

unsafe fn uninstall() {
  if msg(S::UnQ, 0x24) != 6 { return; }
  close_running(); set_startup(false);
  RegDeleteKeyW(HKCU, UNKEY.as_ptr());
  let (mut p, mut exe) = ([0u16; MAX_PATH], [0u16; MAX_PATH]);
  folder(2, LNK, &mut p); DeleteFileW(p.as_ptr());
  DeleteFileW(INI.as_ptr());
  folder(0x1A, w!("\\DockLeger"), &mut p); RemoveDirectoryW(p.as_ptr());
  exe_path(&mut exe); exe_dir(&mut p);
  // un exe ne peut pas s'effacer lui-même : cmd le fait juste après sa fermeture
  wcopy(&mut TMP, w!("/c ping 127.0.0.1 -n 3>nul&del /f /q "));
  let l = wlen(&TMP); quoted(&mut TMP[l..], &exe, w!("&rmdir "));
  let l = wlen(&TMP); quoted(&mut TMP[l..], &p, w!(""));
  ShellExecuteW(0, null(), w!("cmd.exe").as_ptr(), TMP.as_ptr(), null(), 0);
  msg(S::UnDone, 0x40);
}

// ---------- rendu ----------
#[inline(never)] unsafe fn render() {
  W = N.max(1) as i32 * SLOT + 2 * PAD; HH = SLOT + 2 * PAD - (SLOT - B);
  let mut wa = RECT { l: 0, t: 0, r: 0, b: 0 };
  SystemParametersInfoW(0x30 /*SPI_GETWORKAREA*/, 0, &mut wa, 0);
  let pos = POINT { x: wa.l + (wa.r - wa.l - W) / 2, y: if POSTOP { wa.t } else { wa.b - HH } };
  // image de la fenêtre : créée pour ce dessin puis libérée (Windows garde ce qui est affiché)
  let dc = CreateCompatibleDC(0);
  let mut bi: BITMAPINFO = core::mem::zeroed();
  bi.h.size = 40; bi.h.w = W; bi.h.h = -HH; bi.h.planes = 1; bi.h.bits = 32;
  let mut fb: *mut u32 = null_mut();
  let bm = CreateDIBSection(dc, &bi, 0, &mut fb, 0, 0);
  if bm != 0 {
    SelectObject(dc, bm);
    round_rect(fb, 0, 0, W, HH, PAD + 4, 0x18181C, 190);
    for i in 0..N {
      let (x, y, p, w) = (PAD + i as i32 * SLOT, PAD, ITEMS[i].px, ITEMS[i].pw);
      if i as i32 == HOVER { round_rect(fb, x, y - PAD / 2, SLOT, B + PAD, PAD, 0xFFFFFF, 50); } // surlignage
      if p.is_null() { continue; }
      let step = (w << 16) / B;
      for j in 0..B { for k in 0..B { // mise à l'échelle bilinéaire w → B
        let (sx, sy) = ((k * step + step / 2 - 32768).max(0), (j * step + step / 2 - 32768).max(0));
        let (x0, y0) = ((sx >> 16).min(w - 1), (sy >> 16).min(w - 1));
        let (x1, y1) = ((x0 + 1).min(w - 1), (y0 + 1).min(w - 1));
        let at = |xx: i32, yy: i32| *p.add((yy * w + xx) as usize);
        let (fx, fy) = (((sx >> 8) & 255) as u32, ((sy >> 8) & 255) as u32);
        let mut c = lerp(lerp(at(x0, y0), at(x1, y0), fx), lerp(at(x0, y1), at(x1, y1), fx), fy);
        if i as i32 == PRESSED && !DRAGGED { c = (c & 0xFF000000) | (lerp(c, 0, 90) & 0xFFFFFF); }
        blend(fb.add(((y + j) * W + x + (SLOT - B) / 2 + k) as usize), c);
      } }
    }
    let src = POINT { x: 0, y: 0 }; let sz = SIZE { cx: W, cy: HH };
    let bf = BLENDFUNCTION { op: 0, flags: 0, alpha: 255, fmt: 1 };
    UpdateLayeredWindow(HWND, 0, &pos, &sz, dc, &src, 0, &bf, 2 /*ULW_ALPHA*/);
  }
  DeleteDC(dc); DeleteObject(bm);
  SetProcessWorkingSetSize(GetCurrentProcess(), usize::MAX, usize::MAX); // rend la mémoire inutilisée
}

#[inline(never)] unsafe fn hit(x: i32) -> i32 { let i = (x - PAD) / SLOT; if x >= PAD && i < N as i32 { i } else { -1 } }

unsafe fn menu(i: i32, x: i32, y: i32) {
  let m = CreatePopupMenu();
  let start = is_startup();
  // (identifiant, texte, coché) ; identifiant 0 = séparateur
  for &(id, t, c) in &[(1, S::Remove, false), (0, S::Remove, false), (7, S::Add, false), (0, S::Remove, false), (2, S::Bottom, !POSTOP), (3, S::Top, POSTOP),
                       (4, S::Startup, start), (5, S::Lang, false), (0, S::Remove, false), (6, S::Quit, false)][if i < 0 { 2 } else { 0 }..] {
    AppendMenuW(m, if id == 0 { 0x800 } else { c as u32 * 8 }, id, s(t));
  }
  let mut pt = POINT { x, y }; ClientToScreen(HWND, &mut pt);
  SetForegroundWindow(HWND);
  let cmd = TrackPopupMenu(m, 0x102 | if POSTOP { 0 } else { 0x20 } /*RETURNCMD|RIGHTBUTTON|BOTTOMALIGN*/, pt.x, pt.y, 0, HWND, 0);
  DestroyMenu(m);
  match cmd {
    1 => { free(ITEMS[i as usize].px as *mut u8); N -= 1; shift(i as usize, N - i as usize, false); HOVER = -1; }
    2 | 3 => POSTOP = cmd == 3,
    4 => set_startup(!start),
    5 => ENGLISH = !ENGLISH,
    6 => { DestroyWindow(HWND); return; }
    7 => { // le dialogue (comdlg32) n'est chargé que le temps de son ouverture
      let dll = LoadLibraryW(w!("comdlg32.dll").as_ptr());
      let f = GetProcAddress(dll, b"GetOpenFileNameW\0".as_ptr());
      if f == 0 { return; }
      let mut path = [0u16; MAX_PATH];
      let mut of: OPENFILENAMEW = core::mem::zeroed();
      of.size = core::mem::size_of::<OPENFILENAMEW>() as u32; of.owner = HWND; of.filter = s(S::Filter);
      of.file = path.as_mut_ptr(); of.max_file = MAX_PATH as u32; of.flags = 0x181004; // FILEMUSTEXIST|EXPLORER|NODEREFERENCELINKS|HIDEREADONLY
      let open: unsafe extern "win64" fn(*mut OPENFILENAMEW) -> i32 = core::mem::transmute(f);
      let ok = open(&mut of) != 0;
      FreeLibrary(dll);
      if !ok { return; }
      add_item(path.as_ptr(), N);
    }
    _ => return,
  }
  save(); render();
}

unsafe extern "win64" fn wndproc(h: H, m: u32, wp: usize, lp: isize) -> isize {
  let (x, y) = (lp as i16 as i32, (lp >> 16) as i16 as i32);
  let i = hit(x);
  match m {
    0x0200 /*WM_MOUSEMOVE*/ => {
      if !TRACKING { let mut t = TRACKMOUSEEVENT { cb: 24, flags: 2 /*TME_LEAVE*/, hwnd: h, hover: 0 }; TrackMouseEvent(&mut t); TRACKING = true; }
      let mut i = i;
      if PRESSED >= 0 { // icône tenue : elle suit la souris
        if i >= 0 && i != PRESSED {
          let (a, b) = (PRESSED as usize, i as usize);
          let t = ITEMS[a];
          if b > a { shift(a, b - a, false); } else { shift(b, a - b, true); }
          ITEMS[b] = t; PRESSED = i; DRAGGED = true;
        }
        i = PRESSED;
      }
      if i != HOVER { HOVER = i; render(); }
    }
    0x02A3 /*WM_MOUSELEAVE*/ => { TRACKING = false; if PRESSED < 0 { HOVER = -1; render(); } }
    0x0201 /*WM_LBUTTONDOWN*/ => if i >= 0 { PRESSED = i; DRAGGED = false; SetCapture(h); render(); },
    0x0202 /*WM_LBUTTONUP*/ => {
      let p = PRESSED; PRESSED = -1;
      if p >= 0 {
        ReleaseCapture();
        if DRAGGED { save(); } else if i == p {
          let mut path = [0u16; MAX_PATH];
          ExpandEnvironmentStringsW(ITEMS[p as usize].raw.as_ptr(), path.as_mut_ptr(), MAX_PATH as u32);
          ShellExecuteW(h, null(), path.as_ptr(), null(), null(), 1);
        }
        HOVER = if y < 0 || y >= HH { -1 } else { i };
        render();
      }
    }
    0x0205 /*WM_RBUTTONUP*/ => menu(i, x, y),
    0x0233 /*WM_DROPFILES*/ => {
      let mut p = POINT { x: 0, y: 0 }; DragQueryPoint(wp, &mut p);
      let mut at = ((p.x - PAD + SLOT / 2) / SLOT).max(0) as usize;
      for k in 0..DragQueryFileW(wp, 0xFFFFFFFF, null_mut(), 0) {
        DragQueryFileW(wp, k, TMP.as_mut_ptr(), MAX_PATH as u32);
        add_item(TMP.as_ptr(), at); at += 1;
      }
      DragFinish(wp); save(); render();
    }
    0x007E | 0x001A /*WM_DISPLAYCHANGE, WM_SETTINGCHANGE*/ => render(),
    0x0002 /*WM_DESTROY*/ => PostQuitMessage(0),
    _ => return DefWindowProcW(h, m, wp, lp),
  }
  0
}

unsafe fn run() {
  let (mut dir, mut home) = ([0u16; MAX_PATH], [0u16; MAX_PATH]);
  exe_dir(&mut dir);
  folder(0x1C /*CSIDL_LOCAL_APPDATA*/, w!("\\Programs\\DockLeger"), &mut home);
  wcopy(&mut INI, &dir); wcat(&mut INI, w!("\\dock.ini"));
  let portable = GetFileAttributesW(INI.as_ptr()) != INVALID;
  if !portable { folder(0x1A /*CSIDL_APPDATA*/, w!("\\DockLeger"), &mut INI); CreateDirectoryW(INI.as_ptr(), 0); wcat(&mut INI, w!("\\dock.ini")); }
  POSTOP = get(w!("Top")); ENGLISH = get(w!("English"));
  CoInitializeEx(0, 6);
  if cmdline_ends(w!("/uninstall")) { return uninstall(); }
  if !portable && !wieq(&dir, &home) { // lancé depuis un téléchargement : installer ou rester portable ?
    match msg(S::Install, 0x23 /*YESNOCANCEL|QUESTION*/) {
      6 => return install(&mut home),
      7 => { wcopy(&mut INI, &dir); wcat(&mut INI, w!("\\dock.ini")); }
      _ => return,
    }
  }
  CreateMutexW(0, 0, CLASS.as_ptr());
  if GetLastError() == 183 /*déjà lancé*/ { return; }
  let sdc = GetDC(0);
  let dpi = GetDeviceCaps(sdc, 88 /*LOGPIXELSX*/);
  ReleaseDC(0, sdc);
  B = MulDiv(48, dpi, 96); SLOT = B + B / 3; PAD = B / 6;
  let mut wc: WNDCLASSEXW = core::mem::zeroed();
  wc.cb_size = core::mem::size_of::<WNDCLASSEXW>() as u32; wc.wndproc = Some(wndproc);
  wc.class = CLASS.as_ptr(); wc.cursor = LoadCursorW(0, 32512); wc.hinst = GetModuleHandleW(null());
  RegisterClassExW(&wc);
  // fenêtre en couches, hors barre des tâches, qui ne prend pas le focus (les autres fenêtres passent devant)
  HWND = CreateWindowExW(0x08080080, CLASS.as_ptr(), APPNAME.as_ptr(), 0x80000000, 0, 0, 1, 1, 0, 0, wc.hinst, 0);
  let mut k = 1;
  while k <= MAXITEMS && GetPrivateProfileStringW(w!("Dock").as_ptr(), num(k).as_ptr(), w!("").as_ptr(), TMP.as_mut_ptr(), MAX_PATH as u32, INI.as_ptr()) != 0 {
    add_item(TMP.as_ptr(), N); k += 1;
  }
  if N == 0 { // dock vide : quelques programmes de Windows pour commencer
    for d in [w!("%windir%\\explorer.exe") as &[u16], w!("%windir%\\notepad.exe"), w!("%windir%\\System32\\calc.exe")] { add_item(d.as_ptr(), N); }
    save();
  }
  render();
  DragAcceptFiles(HWND, 1);
  ShowWindow(HWND, 4 /*SW_SHOWNOACTIVATE*/);
  let mut m: MSG = core::mem::zeroed();
  while GetMessageW(&mut m, 0, 0, 0) > 0 { DispatchMessageW(&m); }
}

#[unsafe(no_mangle)]
pub unsafe extern "win64" fn start() -> ! { run(); ExitProcess(0) }
