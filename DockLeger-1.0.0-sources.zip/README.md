# Dock Léger (Rust)

Dock de lancement Windows façon RocketDock, en Rust `no_std` : pas de bibliothèque standard, pas de runtime,
uniquement les DLL système (user32, gdi32, shell32…). Licence MIT — christ13430.

- `src/dock.rs` — le dock (fenêtre en couches à alpha par pixel, zoom animé, glisser-déposer, menu FR/EN, config INI)
- `src/setup.rs` — l'installateur (utilisateur courant, sans droits admin, menu Démarrer, désinstallation Windows)
- `src/common.rs` — déclarations Win32, chaînes UTF-16 à la compilation (`w!`), fonctions mémoire

## Construire (depuis Linux, comme ici)
`./build.sh` : rustc produit l'IR LLVM, `tools/ll18.py` l'adapte et la recible vers `x86_64-pc-windows-msvc`,
clang la compile, lld-link fait l'exe. Les chemins de panique de `core` deviennent une sortie propre (`tools/stubs.py`).
Il faut rustc, clang/lld/llvm-rc/llvm-dlltool (LLVM 18) et Python 3.

## Où sont les réglages
- portable : `dock.ini` à côté de l'exe (s'il existe)
- installé : `%APPDATA%\DockLeger\dock.ini`
