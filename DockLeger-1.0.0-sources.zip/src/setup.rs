// Installateur de Dock Léger — Rust sans std. Installe pour l'utilisateur courant, sans droits administrateur.
// (c) christ13430 — licence MIT
#![no_std]
#![no_main]
#![allow(unsafe_op_in_unsafe_fn, clippy::all)]

#[macro_use]
mod common;
use common::*;
use core::ptr::null;

const TITLE: &[u16] = w!("Dock Léger — installation");
const UNKEY: &[u16] = w!("Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\DockLeger");
static CLSID_SHELLLINK: GUID = GUID { d1: 0x00021401, d2: 0, d3: 0, d4: [0xC0, 0, 0, 0, 0, 0, 0, 0x46] };
static IID_ISHELLLINKW: GUID = GUID { d1: 0x000214F9, d2: 0, d3: 0, d4: [0xC0, 0, 0, 0, 0, 0, 0, 0x46] };
static IID_IPERSISTFILE: GUID = GUID { d1: 0x0000010B, d2: 0, d3: 0, d4: [0xC0, 0, 0, 0, 0, 0, 0, 0x46] };

/// appelle la méthode n° `i` de la vtable d'un objet COM
unsafe fn vt(o: usize, i: usize) -> usize { *(*(o as *const *const usize)).add(i) }

unsafe fn shortcut(exe: &[u16], dir: &[u16], lnk: &[u16]) -> bool {
  let mut sl = 0usize; let mut pf = 0usize;
  if CoCreateInstance(&CLSID_SHELLLINK, 0, 1 /*INPROC_SERVER*/, &IID_ISHELLLINKW, &mut sl) != 0 { return false; }
  type SetStr = unsafe extern "win64" fn(usize, *const u16) -> i32;
  type Qi = unsafe extern "win64" fn(usize, *const GUID, *mut usize) -> i32;
  type Save = unsafe extern "win64" fn(usize, *const u16, i32) -> i32;
  type Rel = unsafe extern "win64" fn(usize) -> u32;
  let f: SetStr = core::mem::transmute(vt(sl, 20)); f(sl, exe.as_ptr());              // SetPath
  let f: SetStr = core::mem::transmute(vt(sl, 9)); f(sl, dir.as_ptr());               // SetWorkingDirectory
  let f: SetStr = core::mem::transmute(vt(sl, 7)); f(sl, w!("Dock de lancement léger").as_ptr()); // SetDescription
  let qi: Qi = core::mem::transmute(vt(sl, 0));
  let mut okk = false;
  if qi(sl, &IID_IPERSISTFILE, &mut pf) == 0 {
    let save: Save = core::mem::transmute(vt(pf, 6)); okk = save(pf, lnk.as_ptr(), 1) == 0;
    let rel: Rel = core::mem::transmute(vt(pf, 2)); rel(pf);
  }
  let rel: Rel = core::mem::transmute(vt(sl, 2)); rel(sl);
  okk
}

unsafe fn reg_str(k: H, name: &[u16], v: &[u16]) {
  RegSetValueExW(k, name.as_ptr(), 0, 1 /*REG_SZ*/, v.as_ptr() as *const u8, ((wlen(v) + 1) * 2) as u32);
}
unsafe fn reg_dword(k: H, name: &[u16], v: u32) {
  RegSetValueExW(k, name.as_ptr(), 0, 4 /*REG_DWORD*/, &v as *const u32 as *const u8, 4);
}

unsafe fn run() -> u32 {
  let fr = GetUserDefaultUILanguage() & 0x3FF == 0x0C; // Windows en français ?
  let t = |a: &'static [u16], b: &'static [u16]| if fr { a } else { b };
  let ask = |m: &[u16]| MessageBoxW(0, m.as_ptr(), TITLE.as_ptr(), 0x24 /*YESNO|QUESTION*/) == 6;
  let info = |m: &[u16], icon: u32| { MessageBoxW(0, m.as_ptr(), TITLE.as_ptr(), icon); };

  if !ask(t(w!("Installer Dock Léger 1.0.0 ?\n\nDossier : %LOCALAPPDATA%\\Programs\\DockLeger\nAucun droit administrateur n'est nécessaire."),
            w!("Install Dock Léger 1.0.0?\n\nFolder: %LOCALAPPDATA%\\Programs\\DockLeger\nNo administrator rights needed."))) { return 0; }

  // ferme une version déjà lancée pour pouvoir la remplacer
  let old = FindWindowW(w!("DockLegerWnd").as_ptr(), null());
  if old != 0 { PostMessageW(old, 0x0010 /*WM_CLOSE*/, 0, 0); Sleep(800); }

  let (mut dir, mut exe, mut lnk) = ([0u16; MAX_PATH], [0u16; MAX_PATH], [0u16; MAX_PATH]);
  SHGetFolderPathW(0, 0x1C /*CSIDL_LOCAL_APPDATA*/, 0, 0, dir.as_mut_ptr());
  wcat(&mut dir, w!("\\Programs")); CreateDirectoryW(dir.as_ptr(), 0);
  wcat(&mut dir, w!("\\DockLeger")); CreateDirectoryW(dir.as_ptr(), 0);
  wcopy(&mut exe, &dir); wcat(&mut exe, w!("\\DockLeger.exe"));

  // DockLeger.exe est rangé dans les ressources de l'installateur
  let hm = GetModuleHandleW(null());
  let r = FindResourceW(hm, 101, 10 /*RT_RCDATA*/);
  let (data, size) = if r != 0 { (LockResource(LoadResource(hm, r)), SizeofResource(hm, r)) } else { (null(), 0) };
  let f = CreateFileW(exe.as_ptr(), 0x40000000 /*GENERIC_WRITE*/, 0, 0, 2 /*CREATE_ALWAYS*/, 0x80, 0);
  let mut written = 0u32;
  let good = !data.is_null() && f != usize::MAX && ok(WriteFile(f, data, size, &mut written, 0)) && written == size;
  if f != usize::MAX { CloseHandle(f); }
  if !good {
    info(t(w!("Impossible d'écrire DockLeger.exe.\nFermez le dock s'il est ouvert, puis réessayez."),
           w!("Could not write DockLeger.exe.\nClose the dock if it is running, then try again.")), 0x10);
    return 1;
  }

  // raccourci dans le menu Démarrer
  CoInitializeEx(0, 2 /*APARTMENTTHREADED*/);
  SHGetFolderPathW(0, 0x02 /*CSIDL_PROGRAMS*/, 0, 0, lnk.as_mut_ptr());
  wcat(&mut lnk, w!("\\Dock Léger.lnk"));
  shortcut(&exe, &dir, &lnk);

  // entrée « Applications installées » de Windows (pour désinstaller)
  let mut k = 0;
  if RegCreateKeyExW(HKCU, UNKEY.as_ptr(), 0, 0, 0, 0x20006 /*KEY_WRITE*/, 0, &mut k, 0) == 0 {
    let mut un = [0u16; MAX_PATH + 16];
    wcopy(&mut un, w!("\"")); wcat(&mut un, &exe); wcat(&mut un, w!("\" /uninstall"));
    reg_str(k, w!("DisplayName"), w!("Dock Léger"));
    reg_str(k, w!("DisplayVersion"), w!("1.0.0"));
    reg_str(k, w!("Publisher"), w!("christ13430"));
    reg_str(k, w!("DisplayIcon"), &exe);
    reg_str(k, w!("InstallLocation"), &dir);
    reg_str(k, w!("UninstallString"), &un);
    reg_dword(k, w!("NoModify"), 1); reg_dword(k, w!("NoRepair"), 1);
    reg_dword(k, w!("EstimatedSize"), (size + 1023) / 1024);
    RegCloseKey(k);
  }

  if ask(t(w!("Lancer Dock Léger au démarrage de Windows ?"), w!("Start Dock Léger with Windows?"))) {
    let mut run = 0;
    if RegOpenKeyExW(HKCU, w!("Software\\Microsoft\\Windows\\CurrentVersion\\Run").as_ptr(), 0, 0x20006, &mut run) == 0 {
      let mut v = [0u16; MAX_PATH + 4];
      wcopy(&mut v, w!("\"")); wcat(&mut v, &exe); wcat(&mut v, w!("\""));
      reg_str(run, w!("DockLeger"), &v); RegCloseKey(run);
    }
  }

  ShellExecuteW(0, w!("open").as_ptr(), exe.as_ptr(), null(), dir.as_ptr(), 1);
  info(t(w!("Dock Léger est installé !\n\n• Glissez vos raccourcis sur le dock pour les ajouter.\n• Clic droit sur le dock pour les réglages (position, taille, English…).\n• Désinstallation : Paramètres › Applications."),
         w!("Dock Léger is installed!\n\n• Drop your shortcuts on the dock to add them.\n• Right-click the dock for settings (position, size, Français…).\n• Uninstall: Settings › Apps.")), 0x40);
  0
}

#[unsafe(no_mangle)]
pub unsafe extern "win64" fn start() -> ! { ExitProcess(run()) }
