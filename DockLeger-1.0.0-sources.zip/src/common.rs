// common.rs — API Win32 minimale (x64), chaînes UTF-16 et utilitaires, sans std ni runtime.
#![allow(non_snake_case, non_camel_case_types, dead_code, clippy::all)]

pub type H = usize; // handle Windows (HWND, HDC, HICON…)
pub type WndProc = unsafe extern "win64" fn(H, u32, usize, isize) -> isize;

#[repr(C)] #[derive(Clone, Copy)] pub struct POINT { pub x: i32, pub y: i32 }
#[repr(C)] pub struct SIZE { pub cx: i32, pub cy: i32 }
#[repr(C)] pub struct RECT { pub l: i32, pub t: i32, pub r: i32, pub b: i32 }
#[repr(C)] pub struct MSG { pub hwnd: H, pub message: u32, pub wparam: usize, pub lparam: isize, pub time: u32, pub pt: POINT, pub lprivate: u32 }
#[repr(C)] pub struct WNDCLASSEXW { pub cb_size: u32, pub style: u32, pub wndproc: Option<WndProc>, pub cls_extra: i32, pub wnd_extra: i32,
  pub hinst: H, pub icon: H, pub cursor: H, pub bg: H, pub menu: *const u16, pub class: *const u16, pub icon_sm: H }
#[repr(C)] pub struct BLENDFUNCTION { pub op: u8, pub flags: u8, pub alpha: u8, pub fmt: u8 }
#[repr(C)] pub struct BITMAPINFOHEADER { pub size: u32, pub w: i32, pub h: i32, pub planes: u16, pub bits: u16, pub compr: u32,
  pub size_img: u32, pub xppm: i32, pub yppm: i32, pub used: u32, pub important: u32 }
#[repr(C)] pub struct BITMAPINFO { pub h: BITMAPINFOHEADER, pub colors: [u32; 256] }
#[repr(C)] pub struct BITMAP { pub ty: i32, pub w: i32, pub h: i32, pub wbytes: i32, pub planes: u16, pub bpp: u16, pub bits: usize }
#[repr(C)] pub struct ICONINFO { pub ficon: i32, pub xhot: u32, pub yhot: u32, pub mask: H, pub color: H }
#[repr(C)] pub struct SHFILEINFOW { pub icon: H, pub iicon: i32, pub attrs: u32, pub name: [u16; 260], pub ty: [u16; 80] }
#[repr(C)] pub struct TRACKMOUSEEVENT { pub cb: u32, pub flags: u32, pub hwnd: H, pub hover: u32 }
#[repr(C)] pub struct GUID { pub d1: u32, pub d2: u16, pub d3: u16, pub d4: [u8; 8] }
#[repr(C)] pub struct PMC { pub cb: u32, pub faults: u32, pub peak_ws: usize, pub ws: usize, pub q1: usize, pub q2: usize,
  pub q3: usize, pub q4: usize, pub pagefile: usize, pub peak_pagefile: usize }
#[repr(C)] pub struct OPENFILENAMEW { pub size: u32, pub owner: H, pub hinst: H, pub filter: *const u16, pub cust: *mut u16,
  pub max_cust: u32, pub filter_index: u32, pub file: *mut u16, pub max_file: u32, pub file_title: *mut u16, pub max_title: u32,
  pub init_dir: *const u16, pub title: *const u16, pub flags: u32, pub off: u16, pub ext_off: u16, pub def_ext: *const u16,
  pub cust_data: isize, pub hook: usize, pub template: *const u16, pub reserved: usize, pub reserved2: u32, pub flags_ex: u32 }

pub const HKCU: H = 0xFFFF_FFFF_8000_0001; // HKEY_CURRENT_USER (étendu en signe sur x64)
pub const MAX_PATH: usize = 260;
pub const INVALID: u32 = 0xFFFF_FFFF;

#[link(name = "kernel32")] unsafe extern "win64" {
  pub fn GetModuleHandleW(n: *const u16) -> H;
  pub fn GetModuleFileNameW(m: H, b: *mut u16, n: u32) -> u32;
  pub fn ExitProcess(c: u32) -> !;
  pub fn GetCommandLineW() -> *const u16;
  pub fn GetProcessHeap() -> H;
  pub fn HeapAlloc(h: H, f: u32, n: usize) -> *mut u8;
  pub fn HeapFree(h: H, f: u32, p: *mut u8) -> i32;
  pub fn CreateMutexW(a: usize, o: i32, n: *const u16) -> H;
  pub fn GetLastError() -> u32;
  pub fn GetPrivateProfileStringW(s: *const u16, k: *const u16, d: *const u16, b: *mut u16, n: u32, f: *const u16) -> u32;
  pub fn GetPrivateProfileIntW(s: *const u16, k: *const u16, d: i32, f: *const u16) -> u32;
  pub fn WritePrivateProfileStringW(s: *const u16, k: *const u16, v: *const u16, f: *const u16) -> i32;
  pub fn CreateFileW(n: *const u16, acc: u32, sh: u32, sa: usize, disp: u32, fl: u32, t: H) -> H;
  pub fn WriteFile(h: H, b: *const u8, n: u32, w: *mut u32, o: usize) -> i32;
  pub fn CloseHandle(h: H) -> i32;
  pub fn GetFileAttributesW(n: *const u16) -> u32;
  pub fn CreateDirectoryW(n: *const u16, sa: usize) -> i32;
  pub fn RemoveDirectoryW(n: *const u16) -> i32;
  pub fn DeleteFileW(n: *const u16) -> i32;
  pub fn ExpandEnvironmentStringsW(s: *const u16, d: *mut u16, n: u32) -> u32;
  pub fn SetProcessWorkingSetSize(p: H, a: usize, b: usize) -> i32;
  pub fn GetCurrentProcess() -> H;
  pub fn K32GetProcessMemoryInfo(p: H, c: *mut PMC, n: u32) -> i32;
  pub fn GetUserDefaultUILanguage() -> u16;
  pub fn Sleep(ms: u32);
  pub fn FindResourceW(m: H, n: usize, t: usize) -> H;
  pub fn LoadResource(m: H, r: H) -> H;
  pub fn LockResource(g: H) -> *const u8;
  pub fn SizeofResource(m: H, r: H) -> u32;
  pub fn MulDiv(a: i32, b: i32, c: i32) -> i32;
}
#[link(name = "user32")] unsafe extern "win64" {
  pub fn RegisterClassExW(c: *const WNDCLASSEXW) -> u16;
  pub fn CreateWindowExW(ex: u32, c: *const u16, t: *const u16, s: u32, x: i32, y: i32, w: i32, h: i32, p: H, m: H, i: H, l: usize) -> H;
  pub fn DefWindowProcW(h: H, m: u32, w: usize, l: isize) -> isize;
  pub fn GetMessageW(m: *mut MSG, h: H, a: u32, b: u32) -> i32;
  pub fn TranslateMessage(m: *const MSG) -> i32;
  pub fn DispatchMessageW(m: *const MSG) -> isize;
  pub fn PostQuitMessage(c: i32);
  pub fn PostMessageW(h: H, m: u32, w: usize, l: isize) -> i32;
  pub fn DestroyWindow(h: H) -> i32;
  pub fn ShowWindow(h: H, c: i32) -> i32;
  pub fn LoadCursorW(i: H, n: usize) -> H;
  pub fn LoadIconW(i: H, n: usize) -> H;
  pub fn UpdateLayeredWindow(h: H, dst: H, pos: *const POINT, sz: *const SIZE, src: H, spt: *const POINT, key: u32, bf: *const BLENDFUNCTION, f: u32) -> i32;
  pub fn GetDC(h: H) -> H;
  pub fn ReleaseDC(h: H, dc: H) -> i32;
  pub fn SystemParametersInfoW(a: u32, b: u32, p: *mut RECT, f: u32) -> i32;
  pub fn SetWindowPos(h: H, after: H, x: i32, y: i32, w: i32, hh: i32, f: u32) -> i32;
  pub fn SetTimer(h: H, id: usize, ms: u32, f: usize) -> usize;
  pub fn KillTimer(h: H, id: usize) -> i32;
  pub fn TrackMouseEvent(t: *mut TRACKMOUSEEVENT) -> i32;
  pub fn SetCapture(h: H) -> H;
  pub fn ReleaseCapture() -> i32;
  pub fn CreatePopupMenu() -> H;
  pub fn AppendMenuW(m: H, f: u32, id: usize, s: *const u16) -> i32;
  pub fn TrackPopupMenu(m: H, f: u32, x: i32, y: i32, r: i32, h: H, rc: usize) -> i32;
  pub fn DestroyMenu(m: H) -> i32;
  pub fn SetForegroundWindow(h: H) -> i32;
  pub fn MessageBoxW(h: H, t: *const u16, c: *const u16, f: u32) -> i32;
  pub fn FindWindowW(c: *const u16, t: *const u16) -> H;
  pub fn ClientToScreen(h: H, p: *mut POINT) -> i32;
  pub fn DestroyIcon(i: H) -> i32;
  pub fn GetIconInfo(i: H, ii: *mut ICONINFO) -> i32;
  pub fn DrawTextW(dc: H, s: *const u16, n: i32, rc: *mut RECT, f: u32) -> i32;
}
#[link(name = "gdi32")] unsafe extern "win64" {
  pub fn CreateCompatibleDC(dc: H) -> H;
  pub fn CreateDIBSection(dc: H, bi: *const BITMAPINFO, u: u32, bits: *mut *mut u32, s: H, o: u32) -> H;
  pub fn SelectObject(dc: H, o: H) -> H;
  pub fn DeleteObject(o: H) -> i32;
  pub fn GetDIBits(dc: H, bm: H, start: u32, n: u32, bits: *mut u32, bi: *mut BITMAPINFO, u: u32) -> i32;
  pub fn GetObjectW(o: H, n: i32, p: *mut BITMAP) -> i32;
  pub fn CreateFontW(h: i32, w: i32, e: i32, o: i32, wt: i32, i: u32, u: u32, s: u32, cs: u32, op: u32, cp: u32, q: u32, pf: u32, face: *const u16) -> H;
  pub fn SetTextColor(dc: H, c: u32) -> u32;
  pub fn SetBkMode(dc: H, m: i32) -> i32;
  pub fn GetTextExtentPoint32W(dc: H, s: *const u16, n: i32, sz: *mut SIZE) -> i32;
  pub fn GetDeviceCaps(dc: H, i: i32) -> i32;
  pub fn GdiFlush() -> i32;
}
#[link(name = "shell32")] unsafe extern "win64" {
  pub fn SHGetFileInfoW(p: *const u16, a: u32, fi: *mut SHFILEINFOW, n: u32, f: u32) -> usize;
  pub fn SHGetImageList(l: i32, iid: *const GUID, out: *mut usize) -> i32;
  pub fn ShellExecuteW(h: H, op: *const u16, f: *const u16, args: *const u16, dir: *const u16, show: i32) -> isize;
  pub fn DragAcceptFiles(h: H, a: i32);
  pub fn DragQueryFileW(d: H, i: u32, b: *mut u16, n: u32) -> u32;
  pub fn DragQueryPoint(d: H, p: *mut POINT) -> i32;
  pub fn DragFinish(d: H);
  pub fn SHGetFolderPathW(h: H, csidl: i32, t: H, f: u32, p: *mut u16) -> i32;
}
#[link(name = "ole32")] unsafe extern "win64" {
  pub fn CoInitializeEx(r: usize, f: u32) -> i32;
  pub fn CoCreateInstance(clsid: *const GUID, o: usize, ctx: u32, iid: *const GUID, out: *mut usize) -> i32;
}
#[link(name = "comctl32")] unsafe extern "win64" { pub fn ImageList_GetIcon(il: usize, i: i32, f: u32) -> H; }
#[link(name = "advapi32")] unsafe extern "win64" {
  pub fn RegOpenKeyExW(k: H, s: *const u16, o: u32, sam: u32, out: *mut H) -> i32;
  pub fn RegCreateKeyExW(k: H, s: *const u16, r: u32, c: usize, o: u32, sam: u32, sa: usize, out: *mut H, d: usize) -> i32;
  pub fn RegSetValueExW(k: H, n: *const u16, r: u32, t: u32, d: *const u8, len: u32) -> i32;
  pub fn RegQueryValueExW(k: H, n: *const u16, r: usize, t: usize, d: usize, len: usize) -> i32;
  pub fn RegDeleteValueW(k: H, n: *const u16) -> i32;
  pub fn RegDeleteKeyW(k: H, s: *const u16) -> i32;
  pub fn RegCloseKey(k: H) -> i32;
}
#[link(name = "version")] unsafe extern "win64" {
  pub fn GetFileVersionInfoSizeW(f: *const u16, h: *mut u32) -> u32;
  pub fn GetFileVersionInfoW(f: *const u16, h: u32, n: u32, d: *mut u8) -> i32;
  pub fn VerQueryValueW(b: *const u8, sub: *const u16, out: *mut *const u16, len: *mut u32) -> i32;
}
#[link(name = "comdlg32")] unsafe extern "win64" { pub fn GetOpenFileNameW(o: *mut OPENFILENAMEW) -> i32; }

// ---------- chaînes UTF-16 calculées à la compilation : w!("texte") ----------
pub const fn dec(b: &[u8], i: usize) -> (u32, usize) {
  let c = b[i] as u32;
  if c < 0x80 { (c, 1) }
  else if c < 0xE0 { (((c & 0x1F) << 6) | (b[i + 1] as u32 & 0x3F), 2) }
  else if c < 0xF0 { (((c & 0x0F) << 12) | ((b[i + 1] as u32 & 0x3F) << 6) | (b[i + 2] as u32 & 0x3F), 3) }
  else { (((c & 7) << 18) | ((b[i + 1] as u32 & 0x3F) << 12) | ((b[i + 2] as u32 & 0x3F) << 6) | (b[i + 3] as u32 & 0x3F), 4) }
}
pub const fn u16len(s: &str) -> usize {
  let b = s.as_bytes(); let (mut i, mut n) = (0, 0);
  while i < b.len() { let (cp, l) = dec(b, i); n += if cp >= 0x10000 { 2 } else { 1 }; i += l; }
  n
}
pub const fn utf16<const N: usize>(s: &str) -> [u16; N] {
  let b = s.as_bytes(); let mut o = [0u16; N]; let (mut i, mut j) = (0, 0);
  while i < b.len() {
    let (cp, l) = dec(b, i);
    if cp >= 0x10000 { let v = cp - 0x10000; o[j] = (0xD800 + (v >> 10)) as u16; o[j + 1] = (0xDC00 + (v & 0x3FF)) as u16; j += 2; }
    else { o[j] = cp as u16; j += 1; }
    i += l;
  }
  o
}
macro_rules! w {
  ($s:expr) => {{ const S: &str = $s; const N: usize = $crate::common::u16len(S) + 1;
                 const A: [u16; N] = $crate::common::utf16::<N>(S); &A }};
}

// ---------- tampons UTF-16 terminés par 0 ----------
pub fn wlen(s: &[u16]) -> usize { s.iter().position(|&c| c == 0).unwrap_or(s.len()) }
pub unsafe fn plen(p: *const u16) -> usize { let mut n = 0; while unsafe { *p.add(n) } != 0 { n += 1; } n }
pub fn wcopy(d: &mut [u16], s: &[u16]) { let n = wlen(s).min(d.len() - 1); d[..n].copy_from_slice(&s[..n]); d[n] = 0; }
pub fn wcat(d: &mut [u16], s: &[u16]) { let n = wlen(d); wcopy(&mut d[n..], s); }
pub fn wcat_int(d: &mut [u16], v: i64) {
  let mut t = [0u16; 24]; let mut i = 23; let neg = v < 0; let mut u = if neg { (-v) as u64 } else { v as u64 };
  loop { i -= 1; t[i] = b'0' as u16 + (u % 10) as u16; u /= 10; if u == 0 { break; } }
  if neg { i -= 1; t[i] = b'-' as u16; }
  wcat(d, &t[i..]);
}
pub fn wcat_hex4(d: &mut [u16], v: u16) {
  let mut t = [0u16; 5];
  for k in 0..4 { let x = (v >> (12 - 4 * k)) & 15; t[k] = if x < 10 { b'0' as u16 + x } else { b'a' as u16 + x - 10 }; }
  wcat(d, &t);
}
fn low(c: u16) -> u16 { if (b'A' as u16..=b'Z' as u16).contains(&c) { c + 32 } else { c } }
pub fn wieq(a: &[u16], b: &[u16]) -> bool {
  let (la, lb) = (wlen(a), wlen(b));
  la == lb && (0..la).all(|i| low(a[i]) == low(b[i]))
}
pub fn wfind(s: &[u16], sub: &[u16]) -> Option<usize> {
  let (ls, lu) = (wlen(s), wlen(sub));
  if lu > ls { return None; }
  (0..=ls - lu).find(|&i| (0..lu).all(|k| low(s[i + k]) == low(sub[k])))
}
pub unsafe fn cmdline_has(sub: &[u16]) -> bool {
  let p = unsafe { GetCommandLineW() }; let n = unsafe { plen(p) };
  wfind(unsafe { core::slice::from_raw_parts(p, n + 1) }, sub).is_some()
}
pub unsafe fn exe_path(b: &mut [u16]) { unsafe { GetModuleFileNameW(0, b.as_mut_ptr(), b.len() as u32) }; }
pub unsafe fn exe_dir(b: &mut [u16]) {
  unsafe { exe_path(b) };
  let mut i = wlen(b); while i > 0 && b[i - 1] != b'\\' as u16 { i -= 1; }
  b[if i > 0 { i - 1 } else { 0 }] = 0;
}
pub fn ok(b: i32) -> bool { b != 0 }
pub unsafe fn alloc(n: usize) -> *mut u8 { unsafe { HeapAlloc(GetProcessHeap(), 8 /*ZERO_MEMORY*/, n) } }
pub unsafe fn free(p: *mut u8) { if !p.is_null() { unsafe { HeapFree(GetProcessHeap(), 0, p) }; } }

// ---------- fonctions mémoire attendues par le compilateur (pas de CRT) ----------
#[unsafe(no_mangle)] pub unsafe extern "C" fn memset(d: *mut u8, c: i32, n: usize) -> *mut u8 {
  unsafe { core::arch::asm!("rep stosb", inout("rdi") d => _, inout("rcx") n => _, in("al") c as u8, options(nostack)); } d
}
#[unsafe(no_mangle)] pub unsafe extern "C" fn memcpy(d: *mut u8, s: *const u8, n: usize) -> *mut u8 {
  unsafe { core::arch::asm!("rep movsb", inout("rdi") d => _, inout("rsi") s => _, inout("rcx") n => _, options(nostack)); } d
}
#[unsafe(no_mangle)] pub unsafe extern "C" fn memmove(d: *mut u8, s: *const u8, n: usize) -> *mut u8 {
  if (d as usize) <= (s as usize) || (d as usize) >= (s as usize) + n { return unsafe { memcpy(d, s, n) }; }
  if n > 0 { unsafe { core::arch::asm!("std", "rep movsb", "cld", inout("rdi") d.add(n - 1) => _,
    inout("rsi") s.add(n - 1) => _, inout("rcx") n => _, options(nostack)); } }
  d
}
#[unsafe(no_mangle)] pub unsafe extern "C" fn memcmp(a: *const u8, b: *const u8, n: usize) -> i32 {
  for i in 0..n {
    let (x, y) = unsafe { (core::ptr::read_volatile(a.add(i)), core::ptr::read_volatile(b.add(i))) };
    if x != y { return x as i32 - y as i32; }
  }
  0
}
#[unsafe(no_mangle)] pub unsafe extern "C" fn bcmp(a: *const u8, b: *const u8, n: usize) -> i32 { unsafe { memcmp(a, b, n) } }
#[unsafe(no_mangle)] pub static _fltused: i32 = 0;

#[panic_handler]
fn panic(_: &core::panic::PanicInfo) -> ! { unsafe { ExitProcess(3) } }
