// Dock Léger — dock de lancement natif Windows, écrit en Rust sans std ni runtime.
// (c) christ13430 — licence MIT
#![no_std]
#![no_main]
#![allow(static_mut_refs, unsafe_op_in_unsafe_fn, non_upper_case_globals, clippy::all)]

#[macro_use]
mod common;
use common::*;
use core::ptr::null;

const APPNAME: &[u16] = w!("Dock Léger");
const CLASS: &[u16] = w!("DockLegerWnd");
const MAXITEMS: usize = 48;
const RAWLEN: usize = MAX_PATH + 64;
const TW: i32 = 512; // largeur max d'une étiquette

#[derive(Clone, Copy)]
struct Item { raw: [u16; RAWLEN], label: [u16; 64], px: *mut u32, cur: i32, tgt: i32 }
const EMPTY: Item = Item { raw: [0; RAWLEN], label: [0; 64], px: core::ptr::null_mut(), cur: 0, tgt: 0 };

static mut ITEMS: [Item; MAXITEMS] = [EMPTY; MAXITEMS];
static mut N: usize = 0;
static mut HOVER: i32 = -1;
static mut PRESSED: i32 = -1;
static mut DRAGGING: bool = false;
static mut DOWNX: i32 = 0;
static mut TRACKING: bool = false;
static mut ANIMATING: bool = false;
static mut POSTOP: bool = false;
static mut BASE: i32 = 48;
static mut ENGLISH: bool = false;
static mut TOPMOST: bool = true;
static mut DPI: i32 = 96;
static mut B: i32 = 0; static mut Z: i32 = 0; static mut SLOT: i32 = 0; static mut PADX: i32 = 0; static mut PADY: i32 = 0;
static mut BARH: i32 = 0; static mut LBLH: i32 = 0; static mut W: i32 = 0; static mut HH: i32 = 0; static mut BARX: i32 = 0; static mut BARW: i32 = 0;
static mut HWND: H = 0; static mut HINST: H = 0;
static mut HDC_MEM: H = 0; static mut HDC_TXT: H = 0; static mut HBM_FRAME: H = 0; static mut HBM_TXT: H = 0; static mut HFONT: H = 0;
static mut FB: *mut u32 = core::ptr::null_mut(); static mut TB: *mut u32 = core::ptr::null_mut();
static mut FBW: i32 = 0; static mut FBH: i32 = 0; static mut TBH: i32 = 0;
static mut INI: [u16; MAX_PATH] = [0; MAX_PATH];
static mut TMP: [u16; 2048] = [0; 2048];

// ---------- textes FR / EN ----------
#[derive(Clone, Copy)]
enum S { Open, Loc, Remove, Add, Bottom, Top, Size, Small, Medium, Large, Topmost, Startup, Lang, About, Quit,
         Empty, AddTitle, Filter, AboutTxt, MemNow, MemPriv, Tips, UnQ, UnDone, ErrLaunch }
static T: [[&[u16]; 25]; 2] = [[
  w!("Ouvrir"), w!("Ouvrir l'emplacement du fichier"), w!("Retirer du dock"), w!("Ajouter un programme…"),
  w!("Position : en bas"), w!("Position : en haut"), w!("Taille des icônes"), w!("Petite"), w!("Moyenne"), w!("Grande"),
  w!("Toujours au premier plan"), w!("Lancer au démarrage de Windows"), w!("English"), w!("À propos"), w!("Quitter"),
  w!("Glissez vos raccourcis ici"), w!("Ajouter au dock"),
  w!("Programmes et raccourcis\0*.exe;*.lnk;*.url;*.bat;*.cmd\0Tous les fichiers\0*.*\0"),
  w!("Dock Léger 1.0.0\nen Rust, par christ13430 — licence MIT\n\n"), w!("Mémoire utilisée en ce moment : "), w!(" Ko\n(mémoire privée : "),
  w!(" Ko)\n\nAstuces :\n• glissez des fichiers ou raccourcis sur le dock pour les ajouter ;\n• maintenez le clic et glissez une icône pour la déplacer ;\n• clic droit pour les réglages."),
  w!("Désinstaller Dock Léger ?"), w!("Dock Léger a été désinstallé."), w!("Impossible d'ouvrir :\n"),
], [
  w!("Open"), w!("Open file location"), w!("Remove from dock"), w!("Add a program…"),
  w!("Position: bottom"), w!("Position: top"), w!("Icon size"), w!("Small"), w!("Medium"), w!("Large"),
  w!("Always on top"), w!("Start with Windows"), w!("Français"), w!("About"), w!("Quit"),
  w!("Drop your shortcuts here"), w!("Add to dock"),
  w!("Programs and shortcuts\0*.exe;*.lnk;*.url;*.bat;*.cmd\0All files\0*.*\0"),
  w!("Dock Léger 1.0.0\nin Rust, by christ13430 — MIT license\n\n"), w!("Memory in use right now: "), w!(" KB\n(private memory: "),
  w!(" KB)\n\nTips:\n• drop files or shortcuts on the dock to add them;\n• hold the click and drag an icon to move it;\n• right-click for settings."),
  w!("Uninstall Dock Léger?"), w!("Dock Léger has been uninstalled."), w!("Cannot open:\n"),
]];
unsafe fn s(i: S) -> &'static [u16] { T[ENGLISH as usize][i as usize] }

unsafe fn sc(v: i32) -> i32 { MulDiv(v, DPI, 96) }
unsafe fn trim() { SetProcessWorkingSetSize(GetCurrentProcess(), usize::MAX, usize::MAX); }


/// chemin réel d'un élément : sans l'étiquette « |… », variables d'environnement développées
unsafe fn item_path(i: usize, out: &mut [u16; MAX_PATH]) {
  let mut p = ITEMS[i].raw;
  if let Some(k) = wfind(&p, w!("|")) { p[k] = 0; }
  if ExpandEnvironmentStringsW(p.as_ptr(), out.as_mut_ptr(), MAX_PATH as u32) == 0 { wcopy(out, &p); }
}

// ---------- pixels ARGB prémultipliés ----------
fn pm(rgb: u32, a: u32) -> u32 {
  (a << 24) | ((((rgb >> 16) & 255) * a / 255) << 16) | ((((rgb >> 8) & 255) * a / 255) << 8) | ((rgb & 255) * a / 255)
}
fn blend(d: &mut u32, s: u32) {
  let sa = s >> 24;
  if sa == 0 { return; }
  if sa == 255 { *d = s; return; }
  let (ia, o) = (255 - sa, *d);
  let rb = ((o & 0x00FF00FF) * ia >> 8) & 0x00FF00FF;
  let ag = (((o >> 8) & 0x00FF00FF) * ia >> 8) & 0x00FF00FF;
  *d = s + (rb | (ag << 8));
}
fn lerp(a: u32, b: u32, f: u32) -> u32 {
  let rb = (((a & 0xFF00FF) * (256 - f) + (b & 0xFF00FF) * f) >> 8) & 0xFF00FF;
  let ag = ((((a >> 8) & 0xFF00FF) * (256 - f) + ((b >> 8) & 0xFF00FF) * f) >> 8) & 0xFF00FF;
  rb | (ag << 8)
}
fn darken(c: u32, k: u32) -> u32 {
  (c & 0xFF000000) | (((c & 0xFF00FF) * k >> 8) & 0xFF00FF) | ((((c >> 8) & 0xFF) * k >> 8) << 8)
}
fn isqrt(mut v: i32) -> i32 {
  let (mut r, mut b) = (0i32, 1i32 << 30);
  while b > v { b >>= 2; }
  while b != 0 { if v >= r + b { v -= r + b; r = (r >> 1) + b; } else { r >>= 1; } b >>= 2; }
  r
}
/// couverture 0..256 d'un pixel dans un rectangle arrondi (anticrénelé)
fn rcov(px: i32, py: i32, x: i32, y: i32, w: i32, h: i32, r: i32) -> i32 {
  if px < x || py < y || px >= x + w || py >= y + h { return 0; }
  let cx = if px < x + r { x + r } else if px >= x + w - r { x + w - r } else { return 256 };
  let cy = if py < y + r { y + r } else if py >= y + h - r { y + h - r } else { return 256 };
  let (fx, fy) = (px * 16 + 8 - cx * 16, py * 16 + 8 - cy * 16);
  let c = r * 16 - isqrt(fx * fx + fy * fy) + 8;
  if c <= 0 { 0 } else if c >= 16 { 256 } else { c * 16 }
}
unsafe fn fb() -> &'static mut [u32] { core::slice::from_raw_parts_mut(FB, (FBW * FBH) as usize) }

unsafe fn round_rect(x: i32, y: i32, w: i32, h: i32, r: i32, fill: u32, fa: i32, border: u32, ba: i32) {
  let f = fb();
  for py in y.max(0)..(y + h).min(FBH) {
    for px in x.max(0)..(x + w).min(FBW) {
      let co = rcov(px, py, x, y, w, h, r);
      if co == 0 { continue; }
      let ci = if ba != 0 { rcov(px, py, x + 1, y + 1, w - 2, h - 2, r - 1) } else { co };
      let d = &mut f[(py * FBW + px) as usize];
      if ci != 0 { blend(d, pm(fill, (fa * ci >> 8) as u32)); }
      if ba != 0 && co > ci { blend(d, pm(border, (ba * (co - ci) >> 8) as u32)); }
    }
  }
}

// ---------- icônes ----------
unsafe fn bmi(w: i32, h: i32) -> BITMAPINFO {
  let mut bi: BITMAPINFO = core::mem::zeroed();
  bi.h.size = 40; bi.h.w = w; bi.h.h = -h; bi.h.planes = 1; bi.h.bits = 32;
  bi
}

/// pixels prémultipliés d'une HICON (alloués sur le tas) ; libère aussi les bitmaps de l'icône
unsafe fn icon_bits(hi: H, pw: &mut i32, ph: &mut i32) -> *mut u32 {
  let mut ii: ICONINFO = core::mem::zeroed();
  let mut bm: BITMAP = core::mem::zeroed();
  let mut out: *mut u32 = core::ptr::null_mut();
  if hi == 0 || !ok(GetIconInfo(hi, &mut ii)) { return out; }
  if ii.color != 0 && ok(GetObjectW(ii.color, core::mem::size_of::<BITMAP>() as i32, &mut bm))
    && (1..=256).contains(&bm.w) && (1..=256).contains(&bm.h) {
    let (w, h) = (bm.w, bm.h); let n = (w * h) as usize;
    let mut bi = bmi(w, h);
    let dc = GetDC(0);
    let buf = alloc(n * 4) as *mut u32;
    if !buf.is_null() && ok(GetDIBits(dc, ii.color, 0, h as u32, buf, &mut bi, 0)) {
      let px = core::slice::from_raw_parts_mut(buf, n);
      if !px.iter().any(|&c| c >> 24 != 0) { // vieille icône sans alpha : on prend le masque
        let m = alloc(n * 4) as *mut u32;
        if !m.is_null() && ok(GetDIBits(dc, ii.mask, 0, h as u32, m, &mut bi, 0)) {
          let mk = core::slice::from_raw_parts(m, n);
          for i in 0..n { px[i] = (px[i] & 0xFFFFFF) | if mk[i] & 0xFFFFFF != 0 { 0 } else { 0xFF000000 }; }
        } else { for c in px.iter_mut() { *c |= 0xFF000000; } }
        free(m as *mut u8);
      }
      for c in px.iter_mut() { *c = pm(*c & 0xFFFFFF, *c >> 24); }
      *pw = w; *ph = h; out = buf;
    } else { free(buf as *mut u8); }
    ReleaseDC(0, dc);
  }
  if ii.color != 0 { DeleteObject(ii.color); }
  if ii.mask != 0 { DeleteObject(ii.mask); }
  out
}

/// src (w×h) → dst (Z×Z) : moyenne en réduction, bilinéaire en agrandissement
unsafe fn resample(src: &[u32], w: i32, h: i32, dst: &mut [u32]) {
  let z = Z;
  for y in 0..z { for x in 0..z {
    let out = if w >= z {
      let (x0, mut x1, y0, mut y1) = (x * w / z, (x + 1) * w / z, y * h / z, (y + 1) * h / z);
      if x1 <= x0 { x1 = x0 + 1; } if y1 <= y0 { y1 = y0 + 1; }
      let (mut a, mut r, mut g, mut b, mut cnt) = (0u32, 0u32, 0u32, 0u32, 0u32);
      for j in y0..y1.min(h) { for i in x0..x1.min(w) {
        let c = src[(j * w + i) as usize];
        a += c >> 24; r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255; cnt += 1;
      } }
      let cnt = cnt.max(1);
      ((a / cnt) << 24) | ((r / cnt) << 16) | ((g / cnt) << 8) | (b / cnt)
    } else {
      let sx = ((x * w * 256 + w * 128) / z - 128).max(0);
      let sy = ((y * h * 256 + h * 128) / z - 128).max(0);
      let (x0, y0) = ((sx >> 8).min(w - 1), (sy >> 8).min(h - 1));
      let (x1, y1) = ((x0 + 1).min(w - 1), (y0 + 1).min(h - 1));
      let at = |xx: i32, yy: i32| src[(yy * w + xx) as usize];
      let top = lerp(at(x0, y0), at(x1, y0), (sx & 255) as u32);
      let bot = lerp(at(x0, y1), at(x1, y1), (sx & 255) as u32);
      lerp(top, bot, (sy & 255) as u32)
    };
    dst[(y * z + x) as usize] = out;
  } }
}

static IID_IIMAGELIST: GUID = GUID { d1: 0x46EB5926, d2: 0x582E, d3: 0x4017, d4: [0x9F, 0xDF, 0xE8, 0x99, 0x8D, 0xAA, 0x09, 0x50] };

unsafe fn sys_icon(list: i32, idx: i32) -> H {
  let mut il: usize = 0;
  let mut hi = 0;
  if SHGetImageList(list, &IID_IIMAGELIST, &mut il) == 0 && il != 0 {
    hi = ImageList_GetIcon(il, idx, 1 /*ILD_TRANSPARENT*/);
    let vt = *(il as *const *const usize);
    let release: unsafe extern "win64" fn(usize) -> u32 = core::mem::transmute(*vt.add(2)); // IUnknown::Release
    release(il);
  }
  hi
}

unsafe fn load_icon(i: usize) {
  let mut path = [0u16; MAX_PATH];
  item_path(i, &mut path);
  let mut fi: SHFILEINFOW = core::mem::zeroed();
  let sz = core::mem::size_of::<SHFILEINFOW>() as u32;
  if SHGetFileInfoW(path.as_ptr(), 0, &mut fi, sz, 0x4000 /*SYSICONINDEX*/) == 0 {
    SHGetFileInfoW(path.as_ptr(), 0x80, &mut fi, sz, 0x4000 | 0x10 /*USEFILEATTRIBUTES*/); // icône générique
  }
  let (mut w, mut h) = (0, 0);
  let mut px: *mut u32 = core::ptr::null_mut();
  if Z > 48 { // version 256 px, seulement si l'icône en possède vraiment une
    let hi = sys_icon(4 /*SHIL_JUMBO*/, fi.iicon);
    px = icon_bits(hi, &mut w, &mut h);
    if hi != 0 { DestroyIcon(hi); }
    if !px.is_null() { // Windows colle les petites icônes dans le coin haut-gauche du 256 : on les écarte
      let p = core::slice::from_raw_parts(px, (w * h) as usize);
      let (mut mx, mut my) = (0, 0);
      for y in 0..h { for x in 0..w { if p[(y * w + x) as usize] >> 24 != 0 { mx = mx.max(x); my = my.max(y); } } }
      if mx < w / 2 && my < h / 2 { free(px as *mut u8); px = core::ptr::null_mut(); }
    }
  }
  if px.is_null() {
    let hi = sys_icon(2 /*SHIL_EXTRALARGE*/, fi.iicon);
    px = icon_bits(hi, &mut w, &mut h);
    if hi != 0 { DestroyIcon(hi); }
  }
  free(ITEMS[i].px as *mut u8);
  let zz = (Z * Z) as usize;
  ITEMS[i].px = alloc(zz * 4) as *mut u32;
  if !px.is_null() && !ITEMS[i].px.is_null() {
    resample(core::slice::from_raw_parts(px, (w * h) as usize), w, h, core::slice::from_raw_parts_mut(ITEMS[i].px, zz));
  }
  free(px as *mut u8);
}

unsafe fn make_label(i: usize) {
  let raw = ITEMS[i].raw;
  if let Some(k) = wfind(&raw, w!("|")) { wcopy(&mut ITEMS[i].label, &raw[k + 1..]); return; }
  let mut path = [0u16; MAX_PATH];
  item_path(i, &mut path);
  let mut l = wlen(&path);
  while l > 3 && path[l - 1] == b'\\' as u16 { l -= 1; path[l] = 0; }
  let mut st = l; while st > 0 && path[st - 1] != b'\\' as u16 { st -= 1; }
  if st == l { st = 0; }
  let name = &path[st..];
  let nl = wlen(name);
  let mut e = nl; while e > 0 && name[e - 1] != b'.' as u16 { e -= 1; }
  if e > 0 && wieq(&name[e - 1..], w!(".exe")) { // description du programme, déjà traduite par Windows
    let mut hnd = 0u32;
    let size = GetFileVersionInfoSizeW(path.as_ptr(), &mut hnd);
    let vi = if size != 0 { alloc(size as usize) } else { core::ptr::null_mut() };
    let (mut tr, mut len): (*const u16, u32) = (null(), 0);
    if !vi.is_null() && ok(GetFileVersionInfoW(path.as_ptr(), 0, size, vi))
      && ok(VerQueryValueW(vi, w!("\\VarFileInfo\\Translation").as_ptr(), &mut tr, &mut len)) && len >= 4 {
      let mut sub = [0u16; 64];
      wcopy(&mut sub, w!("\\StringFileInfo\\")); wcat_hex4(&mut sub, *tr); wcat_hex4(&mut sub, *tr.add(1));
      wcat(&mut sub, w!("\\FileDescription"));
      let mut desc: *const u16 = null();
      if ok(VerQueryValueW(vi, sub.as_ptr(), &mut desc, &mut len)) && len > 1 && *desc != b' ' as u16 {
        let d = core::slice::from_raw_parts(desc, plen(desc) + 1);
        wcopy(&mut ITEMS[i].label, d); free(vi); return;
      }
    }
    free(vi);
  }
  let mut lab = [0u16; 64];
  wcopy(&mut lab, name);
  let at = GetFileAttributesW(path.as_ptr());
  if e > 1 && (at == INVALID || at & 0x10 == 0) { lab[(e - 1).min(63)] = 0; } // sans extension, sauf dossiers
  ITEMS[i].label = lab;
}

// ---------- configuration (dock.ini en Unicode) ----------
unsafe fn ensure_ini() {
  if GetFileAttributesW(INI.as_ptr()) != INVALID { return; }
  let f = CreateFileW(INI.as_ptr(), 0x40000000, 0, 0, 1 /*CREATE_NEW*/, 0x80, 0);
  if f != usize::MAX { let mut wr = 0; WriteFile(f, [0xFFu8, 0xFE].as_ptr(), 2, &mut wr, 0); CloseHandle(f); }
}
unsafe fn put_int(k: &[u16], v: i32) {
  let mut b = [0u16; 16]; wcat_int(&mut b, v as i64);
  WritePrivateProfileStringW(w!("Dock").as_ptr(), k.as_ptr(), b.as_ptr(), INI.as_ptr());
}
unsafe fn save() {
  ensure_ini();
  put_int(w!("Init"), 1); put_int(w!("Top"), POSTOP as i32); put_int(w!("Size"), BASE);
  put_int(w!("English"), ENGLISH as i32); put_int(w!("Topmost"), TOPMOST as i32);
  WritePrivateProfileStringW(w!("Items").as_ptr(), null(), null(), INI.as_ptr());
  for i in 0..N {
    let mut k = [0u16; 8]; wcat_int(&mut k, i as i64 + 1);
    WritePrivateProfileStringW(w!("Items").as_ptr(), k.as_ptr(), ITEMS[i].raw.as_ptr(), INI.as_ptr());
  }
}
unsafe fn add_item(raw: &[u16], at: usize) -> bool {
  if N >= MAXITEMS || raw[0] == 0 { return false; }
  let at = at.min(N);
  let mut k = N; while k > at { ITEMS[k] = ITEMS[k - 1]; k -= 1; }
  ITEMS[at] = EMPTY;
  wcopy(&mut ITEMS[at].raw, raw);
  ITEMS[at].cur = B * 16; ITEMS[at].tgt = B * 16;
  make_label(at); load_icon(at);
  N += 1;
  true
}
unsafe fn remove_item(i: usize) {
  free(ITEMS[i].px as *mut u8);
  for k in i..N - 1 { ITEMS[k] = ITEMS[k + 1]; }
  N -= 1; ITEMS[N] = EMPTY; HOVER = -1;
}
unsafe fn load_settings() {
  let mut dir = [0u16; MAX_PATH];
  exe_dir(&mut dir);
  wcopy(&mut INI, &dir); wcat(&mut INI, w!("\\dock.ini"));
  if GetFileAttributesW(INI.as_ptr()) == INVALID { // version installée : réglages dans %APPDATA%\DockLeger
    SHGetFolderPathW(0, 0x1A /*CSIDL_APPDATA*/, 0, 0, INI.as_mut_ptr());
    wcat(&mut INI, w!("\\DockLeger")); CreateDirectoryW(INI.as_ptr(), 0); wcat(&mut INI, w!("\\dock.ini"));
  }
  let get = |k: &[u16], d: i32| GetPrivateProfileIntW(w!("Dock").as_ptr(), k.as_ptr(), d, INI.as_ptr()) as i32;
  POSTOP = get(w!("Top"), 0) != 0;
  BASE = get(w!("Size"), 48); if ![32, 48, 64].contains(&BASE) { BASE = 48; }
  ENGLISH = get(w!("English"), 0) != 0;
  TOPMOST = get(w!("Topmost"), 1) != 0;
}
unsafe fn load_items() {
  if GetPrivateProfileIntW(w!("Dock").as_ptr(), w!("Init").as_ptr(), 0, INI.as_ptr()) == 0 { // premier lancement
    for d in [w!("%windir%\\explorer.exe") as &[u16], w!("%windir%\\notepad.exe"),
              w!("%windir%\\System32\\calc.exe"), w!("%windir%\\System32\\Taskmgr.exe")] { add_item(d, N); }
    save(); return;
  }
  for i in 1..=MAXITEMS {
    let mut k = [0u16; 8]; wcat_int(&mut k, i as i64);
    if GetPrivateProfileStringW(w!("Items").as_ptr(), k.as_ptr(), w!("").as_ptr(), TMP.as_mut_ptr(), RAWLEN as u32, INI.as_ptr()) == 0 { break; }
    let mut raw = [0u16; RAWLEN]; wcopy(&mut raw, &TMP); add_item(&raw, N);
  }
}

// ---------- démarrage avec Windows ----------
const RUNKEY: &[u16] = w!("Software\\Microsoft\\Windows\\CurrentVersion\\Run");
unsafe fn is_startup() -> bool {
  let mut k = 0; let mut r = false;
  if RegOpenKeyExW(HKCU, RUNKEY.as_ptr(), 0, 0x20019 /*KEY_READ*/, &mut k) == 0 {
    r = RegQueryValueExW(k, w!("DockLeger").as_ptr(), 0, 0, 0, 0) == 0; RegCloseKey(k);
  }
  r
}
unsafe fn set_startup(on: bool) {
  let mut k = 0;
  if RegOpenKeyExW(HKCU, RUNKEY.as_ptr(), 0, 0x20006 /*KEY_WRITE*/, &mut k) != 0 { return; }
  if on {
    let (mut exe, mut v) = ([0u16; MAX_PATH], [0u16; MAX_PATH + 4]);
    exe_path(&mut exe);
    wcopy(&mut v, w!("\"")); wcat(&mut v, &exe); wcat(&mut v, w!("\""));
    RegSetValueExW(k, w!("DockLeger").as_ptr(), 0, 1 /*REG_SZ*/, v.as_ptr() as *const u8, ((wlen(&v) + 1) * 2) as u32);
  } else { RegDeleteValueW(k, w!("DockLeger").as_ptr()); }
  RegCloseKey(k);
}

// ---------- mise en page et rendu ----------
unsafe fn make_text_dc() {
  if HDC_TXT == 0 { HDC_TXT = CreateCompatibleDC(0); }
  if HBM_TXT != 0 { DeleteObject(HBM_TXT); }
  if HFONT != 0 { DeleteObject(HFONT); }
  TBH = LBLH;
  let bi = bmi(TW, TBH);
  HBM_TXT = CreateDIBSection(HDC_TXT, &bi, 0, &mut TB, 0, 0);
  SelectObject(HDC_TXT, HBM_TXT);
  HFONT = CreateFontW(-sc(13), 0, 0, 0, 600, 0, 0, 0, 1, 0, 0, 4 /*ANTIALIASED*/, 0, w!("Segoe UI").as_ptr());
  SelectObject(HDC_TXT, HFONT);
  SetTextColor(HDC_TXT, 0xFFFFFF); SetBkMode(HDC_TXT, 1 /*TRANSPARENT*/);
}

unsafe fn metrics() {
  B = sc(BASE); Z = B + B / 3;
  SLOT = (Z + (B + Z) / 2) / 2 + sc(4);
  PADX = sc(12); PADY = sc(8); BARH = B + 2 * PADY; LBLH = sc(24);
  HH = PADY + (Z - B) / 2 + Z + sc(6) + LBLH + sc(2);
  BARW = if N > 0 { N as i32 * SLOT + 2 * PADX } else { sc(240) };
  W = BARW + sc(160);
  BARX = (W - BARW) / 2;
}

/// miroir vertical quand le dock est en haut de l'écran
unsafe fn yy(y: i32, h: i32) -> i32 { if POSTOP { HH - y - h } else { y } }

unsafe fn draw_text(txt: &[u16], cx: i32, ytop: i32, bg: bool) {
  let mut sz = SIZE { cx: 0, cy: 0 };
  let len = wlen(txt) as i32; let pad = sc(10);
  GetTextExtentPoint32W(HDC_TXT, txt.as_ptr(), len, &mut sz);
  let mut tw = if sz.cx < TW - 2 { sz.cx + 2 } else { TW };
  let mut lw = tw + 2 * pad;
  if lw > W { lw = W; tw = lw - 2 * pad; }
  let lx = (cx - lw / 2).max(0).min(W - lw);
  if bg { round_rect(lx, ytop, lw, LBLH, LBLH / 2, 0x141418, 225, 0xFFFFFF, 40); }
  let tb = core::slice::from_raw_parts_mut(TB, (TW * TBH) as usize);
  tb.fill(0);
  let mut rc = RECT { l: 0, t: 0, r: tw, b: TBH };
  DrawTextW(HDC_TXT, txt.as_ptr(), -1, &mut rc, 0x20 | 0x04 | 0x8000 | 0x800 /*SINGLELINE|VCENTER|END_ELLIPSIS|NOPREFIX*/);
  GdiFlush();
  let f = fb();
  for y in 0..TBH {
    let fy = ytop + y; if fy < 0 || fy >= FBH { continue; }
    for x in 0..tw {
      let fx = lx + pad + x; if fx < 0 || fx >= FBW { continue; }
      let c = (tb[(y * TW + x) as usize] >> 8) & 255; // couverture du texte (canal vert)
      if c != 0 { blend(&mut f[(fy * FBW + fx) as usize], (c << 24) | (c << 16) | (c << 8) | c); }
    }
  }
}

unsafe fn draw_icon(i: usize, s: i32, dx: i32, dy: i32, dim: bool) {
  if ITEMS[i].px.is_null() || s <= 0 { return; }
  let z = Z;
  let p = core::slice::from_raw_parts(ITEMS[i].px, (z * z) as usize);
  let f = fb();
  let step = (z << 16) / s;
  let samp = |k: i32| { let v = (k * step + step / 2 - 32768).max(0); let a = (v >> 16).min(z - 1); (a, (a + 1).min(z - 1), ((v >> 8) & 255) as u32) };
  for j in 0..s {
    let fy = dy + j; if fy < 0 || fy >= FBH { continue; }
    let (y0, y1, ty) = samp(j);
    for i2 in 0..s {
      let fx = dx + i2; if fx < 0 || fx >= FBW { continue; }
      let (x0, x1, tx) = samp(i2);
      let at = |x: i32, y: i32| p[(y * z + x) as usize];
      let mut c = lerp(lerp(at(x0, y0), at(x1, y0), tx), lerp(at(x0, y1), at(x1, y1), tx), ty);
      if dim { c = darken(c, 170); }
      blend(&mut f[(fy * FBW + fx) as usize], c);
    }
  }
}

unsafe fn render() {
  if FB.is_null() { return; }
  fb().fill(0);
  round_rect(BARX, yy(HH - BARH, BARH), BARW, BARH, sc(14), 0x18181C, 185, 0xFFFFFF, 55);
  if N == 0 { draw_text(s(S::Empty), W / 2, yy(HH - BARH + (BARH - LBLH) / 2, LBLH), false); }
  for pass in [false, true] { // l'icône survolée est dessinée en dernier, par-dessus ses voisines
    for i in 0..N {
      if (i as i32 == HOVER) != pass { continue; }
      let sz = ITEMS[i].cur >> 4; let lift = ((sz - B) / 2).max(0);
      let x = BARX + PADX + i as i32 * SLOT + (SLOT - sz) / 2;
      draw_icon(i, sz, x, yy(HH - PADY - lift - sz, sz), i as i32 == PRESSED && !DRAGGING);
    }
  }
  if HOVER >= 0 && (HOVER as usize) < N {
    let lab = ITEMS[HOVER as usize].label;
    draw_text(&lab, BARX + PADX + HOVER * SLOT + SLOT / 2, yy(sc(2), LBLH), true);
  }
  let src = POINT { x: 0, y: 0 }; let sz = SIZE { cx: W, cy: HH };
  let bf = BLENDFUNCTION { op: 0, flags: 0, alpha: 255, fmt: 1 /*AC_SRC_ALPHA*/ };
  UpdateLayeredWindow(HWND, 0, null(), &sz, HDC_MEM, &src, 0, &bf, 2 /*ULW_ALPHA*/);
}

unsafe fn place() {
  let mut wa = RECT { l: 0, t: 0, r: 0, b: 0 };
  SystemParametersInfoW(0x30 /*SPI_GETWORKAREA*/, 0, &mut wa, 0);
  let x = wa.l + (wa.r - wa.l - W) / 2;
  let y = if POSTOP { wa.t } else { wa.b - HH };
  SetWindowPos(HWND, if TOPMOST { usize::MAX } else { usize::MAX - 1 } /*HWND_TOPMOST / NOTOPMOST*/, x, y, W, HH, 0x10 /*NOACTIVATE*/);
}

unsafe fn relayout() {
  metrics();
  if W != FBW || HH != FBH {
    let bi = bmi(W, HH);
    let mut bits: *mut u32 = core::ptr::null_mut();
    let nb = CreateDIBSection(HDC_MEM, &bi, 0, &mut bits, 0, 0);
    if nb != 0 {
      SelectObject(HDC_MEM, nb);
      if HBM_FRAME != 0 { DeleteObject(HBM_FRAME); }
      HBM_FRAME = nb; FB = bits; FBW = W; FBH = HH;
    }
  }
  if TBH != LBLH { make_text_dc(); }
  place(); render();
}

unsafe fn set_targets() {
  for i in 0..N {
    let d = if HOVER < 0 { 99 } else { (i as i32 - HOVER).abs() };
    ITEMS[i].tgt = (if d == 0 { Z } else if d == 1 { (B + Z) / 2 } else { B }) * 16;
  }
  if !ANIMATING { ANIMATING = true; SetTimer(HWND, 1, 15, 0); }
}
unsafe fn animate() {
  let mut busy = false;
  for i in 0..N {
    let d = ITEMS[i].tgt - ITEMS[i].cur;
    if d == 0 { continue; }
    let st = if d / 3 != 0 { d / 3 } else { d.signum() };
    ITEMS[i].cur += st; busy = true;
  }
  render();
  if !busy { KillTimer(HWND, 1); ANIMATING = false; if HOVER < 0 { trim(); } }
}

unsafe fn hit(x: i32) -> i32 {
  let rx = x - BARX - PADX;
  if rx < 0 { return -1; }
  let i = rx / SLOT;
  if (i as usize) < N { i } else { -1 }
}

unsafe fn launch(i: usize) {
  let mut path = [0u16; MAX_PATH];
  item_path(i, &mut path); let mut dir = path;
  let mut l = wlen(&dir); while l > 0 && dir[l - 1] != b'\\' as u16 { l -= 1; }
  dir[if l > 0 { l - 1 } else { 0 }] = 0;
  let d = if dir[0] != 0 { dir.as_ptr() } else { null() };
  if ShellExecuteW(HWND, null(), path.as_ptr(), null(), d, 1) <= 32 {
    wcopy(&mut TMP, s(S::ErrLaunch)); wcat(&mut TMP, &path);
    MessageBoxW(HWND, TMP.as_ptr(), APPNAME.as_ptr(), 0x30);
  }
}

unsafe fn reload_icons() {
  metrics();
  for i in 0..N { ITEMS[i].cur = B * 16; ITEMS[i].tgt = B * 16; load_icon(i); }
}

unsafe fn menu(i: i32, x: i32, y: i32) {
  let (m, sub) = (CreatePopupMenu(), CreatePopupMenu());
  let chk = |b: bool| if b { 8u32 /*MF_CHECKED*/ } else { 0 };
  let sep = |m: H| { AppendMenuW(m, 0x800, 0, null()); };
  if i >= 0 {
    AppendMenuW(m, 0, 1, s(S::Open).as_ptr()); AppendMenuW(m, 0, 2, s(S::Loc).as_ptr());
    AppendMenuW(m, 0, 3, s(S::Remove).as_ptr()); sep(m);
  }
  AppendMenuW(m, 0, 10, s(S::Add).as_ptr()); sep(m);
  AppendMenuW(m, chk(!POSTOP), 11, s(S::Bottom).as_ptr()); AppendMenuW(m, chk(POSTOP), 12, s(S::Top).as_ptr());
  AppendMenuW(sub, chk(BASE == 32), 13, s(S::Small).as_ptr()); AppendMenuW(sub, chk(BASE == 48), 14, s(S::Medium).as_ptr());
  AppendMenuW(sub, chk(BASE == 64), 15, s(S::Large).as_ptr());
  AppendMenuW(m, 0x10 /*MF_POPUP*/, sub, s(S::Size).as_ptr());
  AppendMenuW(m, chk(TOPMOST), 16, s(S::Topmost).as_ptr()); AppendMenuW(m, chk(is_startup()), 17, s(S::Startup).as_ptr());
  sep(m);
  AppendMenuW(m, 0, 18, s(S::Lang).as_ptr()); AppendMenuW(m, 0, 19, s(S::About).as_ptr()); AppendMenuW(m, 0, 20, s(S::Quit).as_ptr());
  let mut pt = POINT { x, y }; ClientToScreen(HWND, &mut pt);
  SetForegroundWindow(HWND);
  let cmd = TrackPopupMenu(m, 0x100 | 0x2 | if POSTOP { 0 } else { 0x20 } /*RETURNCMD|RIGHTBUTTON|BOTTOMALIGN*/, pt.x, pt.y, 0, HWND, 0);
  PostMessageW(HWND, 0 /*WM_NULL*/, 0, 0);
  DestroyMenu(m);
  let it = i.max(0) as usize;
  match cmd {
    1 => launch(it),
    2 => {
      let mut path = [0u16; MAX_PATH]; item_path(it, &mut path);
      wcopy(&mut TMP, w!("/select,\"")); wcat(&mut TMP, &path); wcat(&mut TMP, w!("\""));
      ShellExecuteW(HWND, null(), w!("explorer.exe").as_ptr(), TMP.as_ptr(), null(), 1);
    }
    3 => { remove_item(it); save(); relayout(); }
    10 => {
      let mut path = [0u16; MAX_PATH];
      let mut of: OPENFILENAMEW = core::mem::zeroed();
      of.size = core::mem::size_of::<OPENFILENAMEW>() as u32; of.owner = HWND;
      of.filter = s(S::Filter).as_ptr(); of.filter_index = 1;
      of.file = path.as_mut_ptr(); of.max_file = MAX_PATH as u32; of.title = s(S::AddTitle).as_ptr();
      of.flags = 0x1000 | 0x80000 | 0x100000 | 4; // FILEMUSTEXIST|EXPLORER|NODEREFERENCELINKS|HIDEREADONLY
      if ok(GetOpenFileNameW(&mut of)) && add_item(&path, N) { save(); relayout(); }
    }
    11 | 12 => { POSTOP = cmd == 12; save(); relayout(); }
    13..=15 => { BASE = [32, 48, 64][(cmd - 13) as usize]; save(); reload_icons(); relayout(); }
    16 => { TOPMOST = !TOPMOST; save(); place(); }
    17 => set_startup(!is_startup()),
    18 => { ENGLISH = !ENGLISH; save(); render(); }
    19 => {
      let mut pmc: PMC = core::mem::zeroed(); pmc.cb = core::mem::size_of::<PMC>() as u32;
      trim(); K32GetProcessMemoryInfo(GetCurrentProcess(), &mut pmc, pmc.cb);
      wcopy(&mut TMP, s(S::AboutTxt)); wcat(&mut TMP, s(S::MemNow)); wcat_int(&mut TMP, (pmc.ws / 1024) as i64);
      wcat(&mut TMP, s(S::MemPriv)); wcat_int(&mut TMP, (pmc.pagefile / 1024) as i64); wcat(&mut TMP, s(S::Tips));
      MessageBoxW(HWND, TMP.as_ptr(), APPNAME.as_ptr(), 0x40);
    }
    20 => { DestroyWindow(HWND); }
    _ => {}
  }
  trim();
}

unsafe extern "win64" fn wndproc(h: H, msg: u32, wp: usize, lp: isize) -> isize {
  let x = (lp & 0xFFFF) as u16 as i16 as i32;
  let y = ((lp >> 16) & 0xFFFF) as u16 as i16 as i32;
  match msg {
    0x0200 /*WM_MOUSEMOVE*/ => {
      if !TRACKING {
        let mut t = TRACKMOUSEEVENT { cb: core::mem::size_of::<TRACKMOUSEEVENT>() as u32, flags: 2 /*TME_LEAVE*/, hwnd: h, hover: 0 };
        TrackMouseEvent(&mut t); TRACKING = true;
      }
      let mut i = hit(x);
      if PRESSED >= 0 {
        if (x - DOWNX).abs() > sc(6) { DRAGGING = true; }
        if DRAGGING && i >= 0 && i != PRESSED { // déplacement de l'icône tenue
          let (from, to) = (PRESSED as usize, i as usize);
          let t = ITEMS[from];
          if to > from { for k in from..to { ITEMS[k] = ITEMS[k + 1]; } } else { let mut k = from; while k > to { ITEMS[k] = ITEMS[k - 1]; k -= 1; } }
          ITEMS[to] = t; PRESSED = i;
        }
        if DRAGGING { i = PRESSED; }
      }
      if i != HOVER { HOVER = i; set_targets(); }
      0
    }
    0x02A3 /*WM_MOUSELEAVE*/ => {
      TRACKING = false;
      if PRESSED < 0 && HOVER != -1 { HOVER = -1; set_targets(); }
      0
    }
    0x0201 /*WM_LBUTTONDOWN*/ => {
      let i = hit(x);
      if i >= 0 { PRESSED = i; DOWNX = x; DRAGGING = false; SetCapture(h); render(); }
      0
    }
    0x0202 /*WM_LBUTTONUP*/ => {
      let (p, d) = (PRESSED, DRAGGING);
      PRESSED = -1; DRAGGING = false;
      if p < 0 { return 0; }
      ReleaseCapture();
      if d { save(); } else if hit(x) == p { launch(p as usize); }
      if x < 0 || y < 0 || x >= W || y >= HH { HOVER = -1; }
      set_targets(); render();
      0
    }
    0x0215 /*WM_CAPTURECHANGED*/ => {
      if PRESSED >= 0 { if DRAGGING { save(); } PRESSED = -1; DRAGGING = false; render(); }
      0
    }
    0x0205 /*WM_RBUTTONUP*/ => { menu(hit(x), x, y); 0 }
    0x0233 /*WM_DROPFILES*/ => {
      let mut p = POINT { x: 0, y: 0 };
      DragQueryPoint(wp, &mut p);
      let mut at = ((p.x - BARX - PADX + SLOT / 2) / SLOT).max(0) as usize;
      let cnt = DragQueryFileW(wp, 0xFFFFFFFF, core::ptr::null_mut(), 0);
      for k in 0..cnt {
        let mut f = [0u16; MAX_PATH];
        if DragQueryFileW(wp, k, f.as_mut_ptr(), MAX_PATH as u32) != 0 && add_item(&f, at) { at = (at + 1).min(N); }
      }
      DragFinish(wp); save(); relayout(); trim();
      0
    }
    0x0113 /*WM_TIMER*/ => { animate(); 0 }
    0x007E /*WM_DISPLAYCHANGE*/ => { place(); 0 }
    0x001A /*WM_SETTINGCHANGE*/ => { if wp == 0x2F /*SPI_SETWORKAREA*/ { place(); } 0 }
    0x0002 /*WM_DESTROY*/ => { PostQuitMessage(0); 0 }
    _ => DefWindowProcW(h, msg, wp, lp),
  }
}

// ---------- désinstallation : Windows lance « DockLeger.exe /uninstall » ----------
unsafe fn uninstall() -> u32 {
  if MessageBoxW(0, s(S::UnQ).as_ptr(), APPNAME.as_ptr(), 0x24 /*YESNO|QUESTION*/) != 6 { return 0; }
  let w = FindWindowW(CLASS.as_ptr(), null());
  if w != 0 { PostMessageW(w, 0x0010 /*WM_CLOSE*/, 0, 0); Sleep(800); }
  set_startup(false);
  RegDeleteKeyW(HKCU, w!("Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\DockLeger").as_ptr());
  let (mut p, mut exe) = ([0u16; MAX_PATH], [0u16; MAX_PATH]);
  SHGetFolderPathW(0, 0x02 /*CSIDL_PROGRAMS*/, 0, 0, p.as_mut_ptr()); wcat(&mut p, w!("\\Dock Léger.lnk")); DeleteFileW(p.as_ptr());
  SHGetFolderPathW(0, 0x1A /*CSIDL_APPDATA*/, 0, 0, p.as_mut_ptr()); wcat(&mut p, w!("\\DockLeger")); let mut dir = p;
  wcat(&mut p, w!("\\dock.ini")); DeleteFileW(p.as_ptr()); RemoveDirectoryW(dir.as_ptr());
  exe_path(&mut exe); exe_dir(&mut dir);
  // l'exe ne peut pas s'effacer lui-même : cmd le fait 2 s après sa fermeture
  wcopy(&mut TMP, w!("/c ping 127.0.0.1 -n 3 > nul & del /f /q \"")); wcat(&mut TMP, &exe);
  wcat(&mut TMP, w!("\" & rmdir \"")); wcat(&mut TMP, &dir); wcat(&mut TMP, w!("\""));
  ShellExecuteW(0, w!("open").as_ptr(), w!("cmd.exe").as_ptr(), TMP.as_ptr(), null(), 0 /*SW_HIDE*/);
  MessageBoxW(0, s(S::UnDone).as_ptr(), APPNAME.as_ptr(), 0x40);
  0
}

unsafe fn run() -> u32 {
  HINST = GetModuleHandleW(null());
  load_settings();
  if cmdline_has(w!("/uninstall")) { return uninstall(); }
  CreateMutexW(0, 0, w!("DockLeger_Instance").as_ptr());
  if GetLastError() == 183 /*ALREADY_EXISTS*/ { return 0; } // une seule instance
  CoInitializeEx(0, 2 | 4);
  let sdc = GetDC(0); DPI = GetDeviceCaps(sdc, 88 /*LOGPIXELSX*/).max(96); ReleaseDC(0, sdc);
  let mut wc: WNDCLASSEXW = core::mem::zeroed();
  wc.cb_size = core::mem::size_of::<WNDCLASSEXW>() as u32; wc.wndproc = Some(wndproc); wc.hinst = HINST;
  wc.class = CLASS.as_ptr(); wc.cursor = LoadCursorW(0, 32512 /*IDC_ARROW*/); wc.icon = LoadIconW(HINST, 1);
  RegisterClassExW(&wc);
  // fenêtre en couches, sans barre des tâches, qui ne vole pas le focus
  let ex = 0x80000 | 0x80 | 0x08000000 | if TOPMOST { 8 } else { 0 };
  HWND = CreateWindowExW(ex, CLASS.as_ptr(), APPNAME.as_ptr(), 0x80000000 /*WS_POPUP*/, 0, 0, 10, 10, 0, 0, HINST, 0);
  if HWND == 0 { return 1; }
  HDC_MEM = CreateCompatibleDC(0);
  metrics(); load_items();
  relayout();
  DragAcceptFiles(HWND, 1);
  ShowWindow(HWND, 4 /*SW_SHOWNOACTIVATE*/);
  trim();
  let mut m: MSG = core::mem::zeroed();
  while GetMessageW(&mut m, 0, 0, 0) > 0 { TranslateMessage(&m); DispatchMessageW(&m); }
  0
}

#[unsafe(no_mangle)]
pub unsafe extern "win64" fn start() -> ! { ExitProcess(run()) }
