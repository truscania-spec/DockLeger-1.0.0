# Les seules fonctions de `core` absentes de l'IR sont les chemins de panique : on les remplace par une sortie propre.
import subprocess, sys
syms = [l.split()[-1] for l in subprocess.check_output(['llvm-nm', '--undefined-only', sys.argv[1]], text=True).splitlines()]
core = [s for s in syms if s.startswith('_R') and ('4core' in s)]
bad = [s for s in core if 'panic' not in s and 'slice_' not in s and 'unwrap_failed' not in s and 'expect_failed' not in s]
if bad: sys.exit('fonctions de core non gérées : %s' % bad)
with open(sys.argv[2], 'w') as f:
    f.write('__declspec(dllimport) void ExitProcess(unsigned);\n')
    # __chkstk : sonde les pages de pile pour les grosses fonctions (comme celle de MSVC)
    f.write("""__asm__(".globl __chkstk\\n__chkstk:\\n sub $16,%rsp\\n mov %r10,(%rsp)\\n mov %r11,8(%rsp)\\n xor %r11,%r11\\n"
 " lea 24(%rsp),%r10\\n sub %rax,%r10\\n cmovb %r11,%r10\\n mov %gs:16,%r11\\n cmp %r11,%r10\\n jae 2f\\n and $-4096,%r10\\n"
 "1: lea -4096(%r11),%r11\\n movb $0,(%r11)\\n cmp %r11,%r10\\n jne 1b\\n"
 "2: mov (%rsp),%r10\\n mov 8(%rsp),%r11\\n add $16,%rsp\\n ret\\n");\n""")
    for s in core: f.write('void %s(void){ ExitProcess(3); }\n' % s)
print('stubs:', len(core))
