# Génère les bibliothèques d'import Windows (.def -> .lib) à partir des blocs #[link] de common.rs
import re, subprocess, sys, os
src = open(sys.argv[1], encoding='utf-8').read(); out = sys.argv[2]
for dll, body in re.findall(r'#\[link\(name = "(\w+)"\)\] unsafe extern "win64" \{(.*?)\n?\}\n', src, re.S):
    names = re.findall(r'pub fn (\w+)\(', body)
    d = os.path.join(out, dll + '.def')
    open(d, 'w').write('LIBRARY %s.dll\nEXPORTS\n%s\n' % (dll, '\n'.join(names)))
    subprocess.check_call(['llvm-dlltool', '-m', 'i386:x86-64', '-d', d, '-l', os.path.join(out, dll + '.lib')])
    print(dll, len(names))
