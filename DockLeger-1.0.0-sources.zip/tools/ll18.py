# Rend l'IR LLVM de rustc (LLVM 22) lisible par LLVM 18 et la recible vers Windows x64.
import re, sys
s = open(sys.argv[1], encoding='utf-8').read()
s = re.sub(r'^target triple = .*$', 'target triple = "x86_64-pc-windows-msvc"', s, flags=re.M)
s = re.sub(r'^target datalayout = .*$', 'target datalayout = "e-m:w-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"', s, flags=re.M)
s = re.sub(r'getelementptr (inbounds )?nuw ', r'getelementptr \1', s)
s = re.sub(r'getelementptr inbounds (nusw )', 'getelementptr inbounds ', s)
s = re.sub(r'getelementptr nusw ', 'getelementptr inbounds ', s)
s = re.sub(r'\bcaptures\(([^()]*)\)', lambda m: 'nocapture' if m.group(1)=='none' else '', s)
s = re.sub(r'\brange\(i\d+ -?\d+, -?\d+\) ', '', s)
s = re.sub(r'\binitializes\(\([^)]*\)(, \([^)]*\))*\) ', '', s)
s = re.sub(r'\bicmp samesign ', 'icmp ', s)
s = re.sub(r'\btrunc (nuw |nsw )+', 'trunc ', s)
s = re.sub(r'\bdead_on_return(\(\d+\))? ', '', s)
s = re.sub(r'\bnofree_\w+ ', '', s)
s = re.sub(r'"target-cpu"="[^"]*"', '"target-cpu"="x86-64"', s)
s = re.sub(r'"target-features"="[^"]*"', '', s)
s = re.sub(r'"probe-stack"="[^"]*"', '', s)
s = re.sub(r'\bmemory\(([^)]*)\)', lambda m: 'memory(' + ', '.join(p for p in m.group(1).split(', ') if not p.startswith(('target_mem', 'errnomem'))) + ')' if m.group(1) else m.group(0), s)
s = s.replace('memory()', '')
for a in ('nocreateundeforpoison', 'nofpclass(all)', 'nofpclass(nan inf)', 'nocallback_unwind'):
    s = s.replace(' ' + a + ' ', ' ').replace(' ' + a + '}', '}')
# intrinsèques plus récents que LLVM 18
s = re.sub(r'^\s*call void @llvm\.lifetime\.(start|end)\.p0\(.*\n', '', s, flags=re.M)
s = s.replace('!"branch_weights", !"expected", ', '!"branch_weights", ')
s = re.sub(r'^declare void @llvm\.lifetime\.(start|end)\.p0\(.*\n', '', s, flags=re.M)
for bits in re.findall(r'@llvm\.[su]cmp\.i8\.i(\d+)', s):
    pass
def cmp_fn(m):
    kind, ty = m.group(1), m.group(2)
    return '@ll18_%scmp_i8_i%s' % (kind, ty)
used = set(re.findall(r'@llvm\.([su])cmp\.i8\.i(\d+)', s))
s = re.sub(r'^declare [^\n]*@llvm\.[su]cmp\.[^\n]*\n', '', s, flags=re.M)
s = re.sub(r'@llvm\.([su])cmp\.i8\.i(\d+)', cmp_fn, s)
for kind, ty in used:
    lt, gt = ('slt', 'sgt') if kind == 's' else ('ult', 'ugt')
    s += ('\ndefine internal i8 @ll18_%scmp_i8_i%s(i%s %%a, i%s %%b) alwaysinline {\n'
          '  %%l = icmp %s i%s %%a, %%b\n  %%g = icmp %s i%s %%a, %%b\n'
          '  %%x = select i1 %%g, i8 1, i8 0\n  %%r = select i1 %%l, i8 -1, i8 %%x\n  ret i8 %%r\n}\n') % (kind, ty, ty, ty, lt, ty, gt, ty)
open(sys.argv[2], 'w', encoding='utf-8').write(s)
