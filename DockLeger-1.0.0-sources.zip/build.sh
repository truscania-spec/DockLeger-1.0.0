#!/bin/sh
# Construit DockLeger.exe et DockLeger-Setup.exe depuis Linux (rustc -> IR LLVM -> clang/lld-link pour Windows x64).
set -e
cd "$(dirname "$0")"; B=build; mkdir -p $B
python3 tools/implibs.py src/common.rs $B
LIBS="$B/kernel32.lib $B/user32.lib $B/gdi32.lib $B/shell32.lib $B/ole32.lib $B/comctl32.lib $B/advapi32.lib $B/version.lib $B/comdlg32.lib"
build() { # $1 = dock|setup, $2 = nom de l'exe
  rustc --edition 2024 --target x86_64-unknown-linux-gnu --crate-type=staticlib -C panic=abort -C opt-level=z \
        -C lto=fat -C codegen-units=1 -C relocation-model=static --emit=llvm-ir -o $B/$1.ll src/$1.rs
  python3 tools/ll18.py $B/$1.ll $B/$1.w.ll
  llvm-as-18 $B/$1.w.ll -o /dev/null   # vérifie l'IR adaptée
  clang --target=x86_64-pc-windows-msvc -Wno-override-module -Os -c $B/$1.w.ll -o $B/$1.obj
  python3 tools/stubs.py $B/$1.obj $B/$1_stubs.c
  clang --target=x86_64-pc-windows-msvc -Os -c $B/$1_stubs.c -o $B/$1_stubs.obj
  (cd res && llvm-rc /nologo /fo ../$B/$1.res $1.rc)
  lld-link /nologo /subsystem:windows,6.0 /entry:start /nodefaultlib /opt:ref /opt:icf /dynamicbase /nxcompat /highentropyva \
           /out:$B/$2 $B/$1.obj $B/$1_stubs.obj $B/$1.res $LIBS
  echo "$2 : $(stat -c %s $B/$2) octets"
}
build dock DockLeger.exe
build setup DockLeger-Setup.exe
